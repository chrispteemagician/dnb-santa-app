# 🎅 DnB Santa - SIMPLE DEPLOYMENT GUIDE

## ✅ What's Included:

- ✅ Full enhanced admin dashboard
- ✅ Bonus video generation
- ✅ Script & notes storage
- ✅ Netlify Functions (automation backend)
- ✅ Pre-built dist folder
- ✅ Everything ready to go

---

## 🚀 DEPLOYMENT (2 Steps):

### **Step 1: Install Netlify CLI** (if not already installed)

```bash
npm install -g netlify-cli
```

### **Step 2: Deploy**

```bash
cd dnb-santa-app
netlify deploy --prod
```

**When prompted:**
- **Publish directory?** → `dist`
- **Functions directory?** → `netlify/functions`

**That's it!** ✅

---

## ⚙️ After Deployment:

### **Add Environment Variables in Netlify:**

Go to: Netlify Dashboard → Your site → Site settings → Environment variables

Add these:

```
ANTHROPIC_API_KEY = [your key]
ELEVENLABS_API_KEY = [your key]
ELEVENLABS_VOICE_ID = CpgDUW6FZ9xBvrG7Zcqz
VISIONSTORY_API_KEY = [your key]
VISIONSTORY_AVATAR_ID = 97f31d98cfbf5ea1fe0474f6b84ec7cd_7102_10_16
RESEND_API_KEY = [your key]
VITE_SUPABASE_URL = [your Supabase URL]
VITE_SUPABASE_ANON_KEY = [your Supabase anon key]
SUPABASE_SERVICE_KEY = [your Supabase service key]
FROM_EMAIL = chris@chrisptee.co.uk
FROM_NAME = DnB Santa
```

### **Redeploy After Adding Variables:**

```bash
netlify deploy --prod
```

---

## ✅ Verify It Worked:

1. Go to your Netlify site URL
2. Check `/admin` - should see enhanced admin
3. Go to Netlify Dashboard → Functions tab
4. Should see: `generate-video-background`
5. Test the "Generate Video" button!

---

## 🎯 Site Features:

### **Public Pages:**
- `/` - Home with pricing tiers
- `/value-order` - VALUE tier order form
- `/business-order` - BUSINESS tier order form
- `/confirmation` - Order confirmation

### **Admin:**
- `/admin` - Enhanced admin dashboard
- Password: `DnBSanta2024!`

### **Admin Features:**
- ✅ Click orders to view full details
- ✅ Edit all fields inline
- ✅ Save admin notes
- ✅ Save scripts for future reference
- ✅ Generate bonus videos
- ✅ Automated video generation

---

## 🔧 Troubleshooting:

**If functions don't work:**
1. Check Netlify → Functions tab
2. Make sure `generate-video-background` is listed
3. Check environment variables are set
4. Redeploy after adding variables

**If admin doesn't load:**
1. Check browser console (F12)
2. Make sure Supabase variables are set
3. Check database schema is updated

---

**That's it! Simple deployment, no GitHub confusion!** 💚🎅

x
