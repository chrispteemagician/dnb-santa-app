# Pending Video Requests to Migrate 🎅

You have **5 real requests** from families waiting for videos. After you deploy to Supabase, run the migration script to transfer them.

---

## Request #1 - Lucy
- **Parent Email:** ian.gilson007@gmail.com
- **Child's Age:** Not provided
- **Submitted:** October 27, 2025 (First request ever!)
- **Details:** Minimal information provided

---

## Request #2 - Danny (Age 5)
- **Parent Email:** chris@chrisptee.co.uk
- **Interests:** Magic tricks
- **Wish List:** Magic set
- **Encouragement:** Dental hygiene
- **Submitted:** November 2, 2025

---

## Request #3 - Charlie Jack (Age 8)
- **Parent Email:** adeyb@gmx.co.uk
- **Interests:** Climbing trees, playing; Brainrot and Roblox
- **Wish List:** Computer with Minecraft
- **Encouragement:** Use his mobile phone less
- **Submitted:** November 2, 2025

---

## Request #4 - Sammy (Age 11)
- **Parent Email:** Sammycbrooks@gmail.com
- **Interests:** Lego
- **Wish List:** Funko pops
- **Encouragement:** Tidying bedroom
- **Submitted:** November 2, 2025

---

## Request #5 - Jonny (Age 6)
- **Parent Email:** chris@chrisptee.co.uk
- **Interests:** Money, gaming
- **Wish List:** Xbox rog handheld
- **Encouragement:** Sharing and not biting
- **Submitted:** November 4, 2025

---

## Migration Instructions

After deploying to Netlify and setting up Supabase:

1. Make sure you've run `supabase-schema.sql` in Supabase SQL Editor
2. Open a terminal in the `dnb-santa-app` folder
3. Run: `npm install`
4. Run: `node migrate-data.js`
5. Check the admin dashboard at `/admin` to verify all 5 requests appear

The migration script will automatically transfer all these requests from TiDB to Supabase with their original submission dates preserved.

---

**Note:** The migration script found 10 total records in TiDB (including test submissions). All will be migrated, but these 5 are the real families waiting for videos. 💚
