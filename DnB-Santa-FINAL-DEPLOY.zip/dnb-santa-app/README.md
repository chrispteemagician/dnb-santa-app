# DnB Santa - Free Personalized Christmas Videos

A React app for managing personalized Christmas video requests, built with Supabase backend.

## Features

- ✅ Public form for video requests
- ✅ Mobile-first admin dashboard
- ✅ Real-time status updates
- ✅ Supabase backend (PostgreSQL)
- ✅ Ready to deploy to Netlify

## Setup Instructions

### 1. Set up Supabase Database

1. Go to your Supabase project: https://lauswgjnlghltkbwszgx.supabase.co
2. Click "SQL Editor" in the left sidebar
3. Copy the contents of `supabase-schema.sql`
4. Paste into the SQL Editor and click "Run"
5. This creates the `video_requests` table with proper permissions

### 2. Update Supabase Credentials (if needed)

The app is already configured with your Supabase credentials:
- Project URL: `https://lauswgjnlghltkbwszgx.supabase.co`
- Anon Key: Already set in `src/lib/supabase.js`
- Service Key: **UPDATE THIS** in `src/lib/supabase.js` for admin operations

### 3. Install Dependencies

```bash
npm install
```

### 4. Run Locally

```bash
npm run dev
```

Visit http://localhost:5173

### 5. Build for Production

```bash
npm run build
```

The `dist` folder will contain your production-ready app.

### 6. Deploy to Netlify

**Option A: Drag & Drop**
1. Run `npm run build`
2. Go to https://app.netlify.com/drop
3. Drag the `dist` folder onto the page
4. Done!

**Option B: GitHub**
1. Push this code to GitHub
2. Connect your GitHub repo to Netlify
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Done!

## Pages

- `/` - Public form for video requests
- `/confirmation/:id` - Confirmation page after submission
- `/admin` - Mobile-first admin dashboard (manage requests)

## Admin Dashboard Features

- 📊 Stats overview (total, pending, completed)
- 🔍 Filter by status (all, pending, processing, completed)
- 📝 View full request details
- ✅ Update request status
- 🎬 Add video URLs when complete
- 📧 Copy parent emails
- 📱 Mobile-optimized interface

## Database Schema

```sql
video_requests
- id (bigserial, primary key)
- child_name (text)
- child_age (integer)
- parent_name (text)
- parent_email (text)
- interests (text)
- wish_list (text)
- encouragement (text)
- video_url (text)
- status (text: pending/processing/completed/failed)
- created_at (timestamp)
- updated_at (timestamp)
```

## Tech Stack

- **Frontend:** React 18 + Vite
- **Styling:** Tailwind CSS
- **Routing:** Wouter
- **Backend:** Supabase (PostgreSQL)
- **Hosting:** Netlify

## Support

Created with 💚 by Chris P Tee - Magic Circle Magician

- Buy Me a Coffee: https://www.buymeacoffee.com/chrisptee
- Ko-fi: https://ko-fi.com/chrisptee

## License

Free to use for personal and commercial purposes.
