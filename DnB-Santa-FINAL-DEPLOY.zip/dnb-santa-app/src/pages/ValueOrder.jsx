import { useState } from 'react'
import { supabase } from '../lib/supabase'

export default function ValueOrder() {
  const [formData, setFormData] = useState({
    child_name: '',
    child_age: '',
    parent_name: '',
    parent_email: '',
    interests: '',
    wish_list: '',
    encouragement: '',
    tier: 'value',
    language: 'English'
  })

  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSubmitting(true)

    try {
      // Submit to Supabase
      const { data, error: submitError } = await supabase
        .from('video_requests')
        .insert([formData])
        .select()

      if (submitError) throw submitError

      // Redirect to PayPal with £15 pre-filled
      window.location.href = 'https://paypal.me/chrisptee/15'
      
    } catch (err) {
      console.error('Error:', err)
      setError('Something went wrong. Please try again or email chris@chrisptee.co.uk')
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-blue-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-blue-700 mb-4">
            VALUE Tier - £15 💙
          </h1>
          <p className="text-lg text-gray-700">
            3 x 1-minute personalized videos in 720p animated quality
          </p>
        </div>

        {/* Benefits */}
        <div className="card mb-8 bg-white">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">What You Get:</h2>
          <ul className="space-y-2">
            <li className="flex items-start">
              <span className="text-blue-500 mr-2 text-xl">✓</span>
              <span><strong>3 x 1-minute videos</strong> - perfect for multiple children or occasions!</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-500 mr-2 text-xl">✓</span>
              <span><strong>720p animated quality</strong> - professional video production</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-500 mr-2 text-xl">✓</span>
              <span><strong>24-48 hour</strong> priority delivery</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-500 mr-2 text-xl">✓</span>
              <span><strong>Detailed personalization</strong> - more interests, more details</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-500 mr-2 text-xl">✓</span>
              <span><strong>Priority support</strong> - your questions answered first</span>
            </li>
          </ul>
        </div>

        {/* Order Form */}
        <div className="card bg-white">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            Tell Me About Your Child 🎅
          </h2>

          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Child's Name */}
            <div>
              <label className="label">Child's Name *</label>
              <input
                type="text"
                name="child_name"
                value={formData.child_name}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            {/* Child's Age */}
            <div>
              <label className="label">Child's Age *</label>
              <input
                type="number"
                name="child_age"
                value={formData.child_age}
                onChange={handleChange}
                className="input-field"
                min="1"
                max="18"
                required
              />
            </div>

            {/* Parent's Name */}
            <div>
              <label className="label">Your Name (Parent/Guardian) *</label>
              <input
                type="text"
                name="parent_name"
                value={formData.parent_name}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="label">Your Email *</label>
              <input
                type="email"
                name="parent_email"
                value={formData.parent_email}
                onChange={handleChange}
                className="input-field"
                required
              />
              <p className="text-sm text-gray-500 mt-1">
                We'll send the video to this email within 24-48 hours
              </p>
            </div>

            {/* Interests */}
            <div>
              <label className="label">What does {formData.child_name || 'your child'} love? *</label>
              <textarea
                name="interests"
                value={formData.interests}
                onChange={handleChange}
                className="input-field"
                rows="4"
                placeholder="e.g., dinosaurs, football, drawing, Minecraft, etc."
                required
              />
              <p className="text-sm text-gray-500 mt-1">
                The more details, the more personalized the video!
              </p>
            </div>

            {/* Wish List */}
            <div>
              <label className="label">What's on their Christmas wish list?</label>
              <textarea
                name="wish_list"
                value={formData.wish_list}
                onChange={handleChange}
                className="input-field"
                rows="3"
                placeholder="e.g., LEGO set, bike, books, etc."
              />
            </div>

            {/* Encouragement */}
            <div>
              <label className="label">What would you like Santa to encourage?</label>
              <textarea
                name="encouragement"
                value={formData.encouragement}
                onChange={handleChange}
                className="input-field"
                rows="3"
                placeholder="e.g., being kind to siblings, doing homework, trying new foods, etc."
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-6 rounded-lg transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {submitting ? 'Processing...' : 'Continue to Payment (£15) 💙'}
            </button>

            <p className="text-sm text-gray-600 text-center">
              After submitting, you'll be redirected to PayPal to complete your £15 payment
            </p>
          </form>
        </div>

        {/* Back to Home */}
        <div className="text-center mt-8">
          <a href="/" className="text-blue-600 hover:underline">
            ← Back to Home
          </a>
        </div>

      </div>
    </div>
  )
}
