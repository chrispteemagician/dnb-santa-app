import { useState } from 'react'
import { supabase } from '../lib/supabase'

export default function BusinessOrder() {
  const [formData, setFormData] = useState({
    child_name: '',
    child_age: '',
    parent_name: '',
    parent_email: '',
    company_name: '',
    interests: '',
    wish_list: '',
    encouragement: '',
    commercial_use: '',
    tier: 'business',
    language: 'English'
  })

  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSubmitting(true)

    try {
      // Submit to Supabase
      const { data, error: submitError } = await supabase
        .from('video_requests')
        .insert([formData])
        .select()

      if (submitError) throw submitError

      // Redirect to PayPal with £50 pre-filled
      window.location.href = 'https://paypal.me/chrisptee/50'
      
    } catch (err) {
      console.error('Error:', err)
      setError('Something went wrong. Please try again or email chris@chrisptee.co.uk')
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-amber-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-amber-700 mb-4">
            BUSINESS Tier - £50+ 💼
          </h1>
          <p className="text-lg text-gray-700">
            Commercial license for business use
          </p>
          <p className="text-md text-gray-600 mt-2">
            Love it? Donate more or tell your business friends about us! 💚
          </p>
        </div>

        {/* Benefits */}
        <div className="card mb-8 bg-white">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">What You Get:</h2>
          <ul className="space-y-2">
            <li className="flex items-start">
              <span className="text-amber-500 mr-2 text-xl">✓</span>
              <span><strong>Commercial license</strong> - use in your business</span>
            </li>
            <li className="flex items-start">
              <span className="text-amber-500 mr-2 text-xl">✓</span>
              <span><strong>Advertising rights</strong> - use in marketing materials</span>
            </li>
            <li className="flex items-start">
              <span className="text-amber-500 mr-2 text-xl">✓</span>
              <span><strong>Corporate events</strong> - perfect for company parties</span>
            </li>
            <li className="flex items-start">
              <span className="text-amber-500 mr-2 text-xl">✓</span>
              <span><strong>Priority delivery</strong> - 24-48 hours</span>
            </li>
            <li className="flex items-start">
              <span className="text-amber-500 mr-2 text-xl">✓</span>
              <span><strong>Pay it forward</strong> - love it? Donate more or refer friends!</span>
            </li>
          </ul>
        </div>

        {/* Order Form */}
        <div className="card bg-white">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            Business Order Details 🎅
          </h2>

          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Company Name */}
            <div>
              <label className="label">Company Name *</label>
              <input
                type="text"
                name="company_name"
                value={formData.company_name}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            {/* Child's Name */}
            <div>
              <label className="label">Child's Name *</label>
              <input
                type="text"
                name="child_name"
                value={formData.child_name}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            {/* Child's Age */}
            <div>
              <label className="label">Child's Age *</label>
              <input
                type="number"
                name="child_age"
                value={formData.child_age}
                onChange={handleChange}
                className="input-field"
                min="1"
                max="18"
                required
              />
            </div>

            {/* Parent's Name */}
            <div>
              <label className="label">Contact Person *</label>
              <input
                type="text"
                name="parent_name"
                value={formData.parent_name}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="label">Business Email *</label>
              <input
                type="email"
                name="parent_email"
                value={formData.parent_email}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            {/* Commercial Use */}
            <div>
              <label className="label">How will you use this video? *</label>
              <textarea
                name="commercial_use"
                value={formData.commercial_use}
                onChange={handleChange}
                className="input-field"
                rows="3"
                placeholder="e.g., employee appreciation, corporate event, marketing campaign, etc."
                required
              />
            </div>

            {/* Interests */}
            <div>
              <label className="label">What does {formData.child_name || 'the child'} love? *</label>
              <textarea
                name="interests"
                value={formData.interests}
                onChange={handleChange}
                className="input-field"
                rows="4"
                placeholder="e.g., dinosaurs, football, drawing, Minecraft, etc."
                required
              />
            </div>

            {/* Wish List */}
            <div>
              <label className="label">What's on their Christmas wish list?</label>
              <textarea
                name="wish_list"
                value={formData.wish_list}
                onChange={handleChange}
                className="input-field"
                rows="3"
                placeholder="e.g., LEGO set, bike, books, etc."
              />
            </div>

            {/* Encouragement */}
            <div>
              <label className="label">What would you like Santa to encourage?</label>
              <textarea
                name="encouragement"
                value={formData.encouragement}
                onChange={handleChange}
                className="input-field"
                rows="3"
                placeholder="e.g., being kind to siblings, doing homework, trying new foods, etc."
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-4 px-6 rounded-lg transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {submitting ? 'Processing...' : 'Continue to Payment (£50) 💼'}
            </button>

            <p className="text-sm text-gray-600 text-center">
              After submitting, you'll be redirected to PayPal to complete your £50 payment.<br/>
              <strong>Love the result? Consider donating more or referring us to your business network!</strong>
            </p>
          </form>
        </div>

        {/* Back to Home */}
        <div className="text-center mt-8">
          <a href="/" className="text-amber-600 hover:underline">
            ← Back to Home
          </a>
        </div>

      </div>
    </div>
  )
}
