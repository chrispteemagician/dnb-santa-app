import { useState } from 'react'
import { useLocation } from 'wouter'
import { supabase } from '../lib/supabase'

export default function Home() {
  const [, setLocation] = useLocation()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  
  const [formData, setFormData] = useState({
    child_name: '',
    child_age: '',
    parent_name: '',
    parent_email: '',
    interests: '',
    wish_list: '',
    encouragement: '',
    language: 'English'
  })

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      // Basic validation
      if (!formData.child_name || !formData.parent_email) {
        throw new Error('Please fill in all required fields')
      }

      // Submit to Supabase
      const { data, error: submitError } = await supabase
        .from('video_requests')
        .insert([{
          child_name: formData.child_name,
          child_age: formData.child_age ? parseInt(formData.child_age) : null,
          parent_name: formData.parent_name,
          parent_email: formData.parent_email,
          interests: formData.interests,
          wish_list: formData.wish_list,
          encouragement: formData.encouragement,
          status: 'pending'
        }])
        .select()

      if (submitError) throw submitError

      // Redirect to confirmation page
      if (data && data[0]) {
        setLocation(`/confirmation/${data[0].id}`)
      }
    } catch (err) {
      setError(err.message)
      setLoading(false)
    }
  }

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 to-green-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-red-600 to-green-600 text-white py-20 px-4">
        <div className="max-w-5xl mx-auto text-center">
          <img 
            src="/dnb-santa-logo.webp" 
            alt="DnB Santa Logo" 
            className="w-48 h-48 mx-auto mb-6 animate-pulse"
          />
          <h1 className="text-7xl font-bold mb-3">🎅 DnB Santa Lingua 🌍</h1>
          <p className="text-3xl font-bold mb-4 text-yellow-300">
            "Every Child Deserves Santa in Their Language"
          </p>
          <p className="text-xl mb-3 max-w-3xl mx-auto">
            Free personalized Christmas videos in <span className="font-bold text-yellow-300">35+ languages</span>
          </p>
          <p className="text-lg mb-6 max-w-2xl mx-auto italic opacity-95">
            Because magic sounds better in your mother tongue
          </p>
          <div className="flex flex-wrap justify-center gap-3 text-sm font-semibold">
            <span className="bg-white/20 px-4 py-2 rounded-full">English</span>
            <span className="bg-white/20 px-4 py-2 rounded-full">Español</span>
            <span className="bg-white/20 px-4 py-2 rounded-full">Français</span>
            <span className="bg-white/20 px-4 py-2 rounded-full">中文</span>
            <span className="bg-white/20 px-4 py-2 rounded-full">العربية</span>
            <span className="bg-white/20 px-4 py-2 rounded-full">हिन्दी</span>
            <span className="bg-white/20 px-4 py-2 rounded-full">Русский</span>
            <span className="bg-white/20 px-4 py-2 rounded-full">+28 more!</span>
          </div>
        </div>
      </div>

      {/* Demo Video Section */}
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="card mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-6">
            See the Magic in Action 🎥
          </h2>
          <div className="aspect-video bg-gray-200 rounded-lg mb-4 flex items-center justify-center">
            <iframe
              className="w-full h-full rounded-lg"
              src="https://www.youtube.com/embed/6zd0_HMqYLY"
              title="DnB Santa Example Video"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
          <p className="text-sm text-gray-600 text-center">
            Free videos are up to 30 seconds and similar to this example
          </p>
          
          {/* Pay it Forward Message */}
          <div className="mt-6 bg-red-100 border-2 border-red-500 rounded-lg p-6">
            <p className="text-center text-gray-800 font-medium leading-relaxed">
              Please Consider Buying Me a Coffee ONLY if You Can Afford to. 
              Otherwise Share and Pay it Forward. 
              You have a Magical Christmas, Love from DnB Santa xx
            </p>
          </div>
        </div>

        {/* What is DnB Santa */}
        <div className="card mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">What is DnB Santa? 🎅</h2>
          <div className="prose max-w-none">
            <p className="text-gray-700 mb-4">
              DnB Santa is a <strong>completely FREE</strong> service offering personalized Christmas video messages 
              for children who need encouragement. Created by Chris P Tee, a Magic Circle magician with 30+ years 
              of experience, each video is crafted with care, magic, and a touch of drum & bass swagger!
            </p>
            <p className="text-gray-700 mb-4">
              Whether your child needs encouragement with homework, being kind to siblings, or just a magical 
              boost of Christmas cheer, DnB Santa is here to help. Videos are up to 30 seconds long and 
              delivered directly to your email.
            </p>
            <p className="text-gray-700">
              This is a <strong>coffeeware</strong> service - free for everyone, with optional donations 
              to support the magic. If you can't donate, just share with others who might need it!
            </p>
          </div>
        </div>

        {/* Pricing Tiers */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          
          {/* FREE Tier */}
          <div className="card bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-500">
            <div className="text-center mb-4">
              <h3 className="text-2xl font-bold text-green-700 mb-2">FREE</h3>
              <div className="text-4xl font-bold text-green-600">£0</div>
              <p className="text-sm text-gray-600 mt-1">Always Free</p>
            </div>
            <ul className="space-y-2 mb-6 text-sm">
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>30-second video</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>3-7 day delivery</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>3 videos per season</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Personal encouragement</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Magic Circle quality</span>
              </li>
            </ul>
            <a href="#request-form" className="btn-primary w-full block text-center text-sm">
              Request Free Video 🎁
            </a>
          </div>

          {/* VALUE Tier */}
          <div className="card bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-500">
            <div className="text-center mb-4">
              <h3 className="text-2xl font-bold text-blue-700 mb-2">VALUE</h3>
              <div className="text-4xl font-bold text-blue-600">£15</div>
              <p className="text-sm text-gray-600 mt-1">One-Time Payment</p>
            </div>
            <ul className="space-y-2 mb-6 text-sm">
              <li className="flex items-start">
                <span className="text-blue-500 mr-2">✓</span>
                <span><strong>3 x 1-minute videos</strong></span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-500 mr-2">✓</span>
                <span><strong>720p animated quality</strong></span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-500 mr-2">✓</span>
                <span><strong>24-48 hour</strong> delivery</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-500 mr-2">✓</span>
                <span>Detailed personalization</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-500 mr-2">✓</span>
                <span>Priority support</span>
              </li>
            </ul>
            <a href="/value-order" className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg text-center block text-sm transition-colors">
              Order VALUE Tier 💙
            </a>
          </div>

          {/* SOCIALS Tier */}
          <div className="card bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-500">
            <div className="text-center mb-4">
              <h3 className="text-2xl font-bold text-purple-700 mb-2">SOCIALS</h3>
              <div className="text-4xl font-bold text-purple-600">FREE</div>
              <p className="text-sm text-gray-600 mt-1">Share & Get More</p>
            </div>
            <ul className="space-y-2 mb-6 text-sm">
              <li className="flex items-start">
                <span className="text-purple-500 mr-2">✓</span>
                <span>Share on social media</span>
              </li>
              <li className="flex items-start">
                <span className="text-purple-500 mr-2">✓</span>
                <span><strong>Bonus videos</strong> unlocked</span>
              </li>
              <li className="flex items-start">
                <span className="text-purple-500 mr-2">✓</span>
                <span>Help spread the magic</span>
              </li>
              <li className="flex items-start">
                <span className="text-purple-500 mr-2">✓</span>
                <span>Support the service</span>
              </li>
              <li className="flex items-start">
                <span className="text-purple-500 mr-2">✓</span>
                <span>Build community</span>
              </li>
            </ul>
            <a href="mailto:chris@chrisptee.co.uk?subject=Social Share for Bonus Videos" className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-lg text-center block text-sm transition-colors">
              Email Screenshot 💜
            </a>
          </div>

          {/* BUSINESS Tier */}
          <div className="card bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-500">
            <div className="text-center mb-4">
              <h3 className="text-2xl font-bold text-amber-700 mb-2">BUSINESS</h3>
              <div className="text-4xl font-bold text-amber-600">£50+</div>
              <p className="text-sm text-gray-600 mt-1">Commercial Use</p>
            </div>
            <ul className="space-y-2 mb-6 text-sm">
              <li className="flex items-start">
                <span className="text-amber-500 mr-2">✓</span>
                <span><strong>Commercial license</strong></span>
              </li>
              <li className="flex items-start">
                <span className="text-amber-500 mr-2">✓</span>
                <span>Use in advertising</span>
              </li>
              <li className="flex items-start">
                <span className="text-amber-500 mr-2">✓</span>
                <span>Corporate events</span>
              </li>
              <li className="flex items-start">
                <span className="text-amber-500 mr-2">✓</span>
                <span>Love it? Donate more!</span>
              </li>
              <li className="flex items-start">
                <span className="text-amber-500 mr-2">✓</span>
                <span>Tell business friends</span>
              </li>
            </ul>
            <a href="/business-order" className="bg-amber-600 hover:bg-amber-700 text-white font-semibold py-3 px-6 rounded-lg text-center block text-sm transition-colors">
              Order for £50 💼
            </a>
          </div>

        </div>>

        {/* Want More Videos */}
        <div className="card mb-12 bg-blue-50">
          <h3 className="text-2xl font-bold text-gray-800 mb-4">Want More Videos? 🎥</h3>
          <p className="text-gray-700 mb-4">
            Need more than 3 videos this season? <strong>Share DnB Santa on social media</strong> and email me at{' '}
            <a href="mailto:chris@chrisptee.co.uk" className="text-blue-600 hover:underline">
              chris@chrisptee.co.uk
            </a>{' '}
            with a screenshot of your post - I'll add bonus videos to your account completely free!
          </p>
          <p className="text-gray-600 text-sm">
            Share on Facebook, Twitter, Instagram, or anywhere you like - help spread the Christmas magic! 🎄✨
          </p>
        </div>

        {/* Want Longer Videos */}
        <div className="card mb-12 bg-purple-50">
          <h3 className="text-2xl font-bold text-gray-800 mb-4">Want Longer Videos? 🎬</h3>
          <p className="text-gray-700 mb-4">
            Need a longer, more detailed video? Check out my{' '}
            <a 
              href="https://www.fiverr.com/s/8zW87Qq" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-purple-600 hover:underline font-semibold"
            >
              Fiverr gig
            </a>{' '}
            for custom video messages up to 2 minutes long with advanced personalization!
          </p>
        </div>

        {/* FAQ Section */}
        <div className="card mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">
            Frequently Asked Questions 🤔
          </h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">
                Is this really free?
              </h3>
              <p className="text-gray-700">
                Yes! Completely free. This is a coffeeware service - if you can afford to donate, 
                that's wonderful. If not, just enjoy the magic and share with others!
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">
                How long are the videos?
              </h3>
              <p className="text-gray-700">
                Free videos are up to 30 seconds long - perfect for a personalized message from Santa 
                with encouragement for your child.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">
                How many videos can I request?
              </h3>
              <p className="text-gray-700">
                You can request up to 3 free videos per family per season. Need more? Just email me 
                at chris@chrisptee.co.uk and I'll add bonus videos to your account!
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">
                How long does it take?
              </h3>
              <p className="text-gray-700">
                Videos are typically delivered within 7 days. I create each one personally, so please 
                be patient - I'm working through requests as fast as I can!
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">
                Who creates the videos?
              </h3>
              <p className="text-gray-700">
                Every video is personally created by Chris P Tee, a Magic Circle magician with 30+ years 
                of experience in entertainment and magic. No AI automation - just real magic!
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">
                Can I donate to support this service?
              </h3>
              <p className="text-gray-700">
                Absolutely! Donations are never required but always appreciated. You can support via{' '}
                <a href="https://www.ko-fi.com/zoom" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                  Ko-fi
                </a>{' '}
                or{' '}
                <a href="https://www.buymeacoffee.com/chrispteemagician" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                  Buy Me a Coffee
                </a>.
              </p>
            </div>
          </div>
        </div>

        {/* Request Form */}
        <div id="request-form" className="card mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">
            Request Your Free Video 🎁
          </h2>

          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Child's Name */}
            <div>
              <label className="label">Child's Name *</label>
              <input
                type="text"
                name="child_name"
                value={formData.child_name}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            {/* Child's Age */}
            <div>
              <label className="label">Child's Age</label>
              <input
                type="number"
                name="child_age"
                value={formData.child_age}
                onChange={handleChange}
                className="input-field"
                min="1"
                max="18"
              />
            </div>

            {/* Parent's Name */}
            <div>
              <label className="label">Your Name (Parent/Guardian)</label>
              <input
                type="text"
                name="parent_name"
                value={formData.parent_name}
                onChange={handleChange}
                className="input-field"
              />
            </div>

            {/* Email */}
            <div>
              <label className="label">Your Email *</label>
              <input
                type="email"
                name="parent_email"
                value={formData.parent_email}
                onChange={handleChange}
                className="input-field"
                required
              />
              <p className="text-sm text-gray-500 mt-1">
                We'll send the video to this email
              </p>
            </div>

            {/* Interests */}
            <div>
              <label className="label">What does {formData.child_name || 'your child'} love?</label>
              <textarea
                name="interests"
                value={formData.interests}
                onChange={handleChange}
                className="input-field"
                rows="3"
                placeholder="e.g., dinosaurs, football, drawing..."
              />
            </div>

            {/* Wish List */}
            <div>
              <label className="label">What's on their Christmas wish list?</label>
              <textarea
                name="wish_list"
                value={formData.wish_list}
                onChange={handleChange}
                className="input-field"
                rows="3"
                placeholder="e.g., a new bike, art supplies, video games..."
              />
            </div>

            {/* Language Selection */}
            <div>
              <label className="label">Preferred Language for Video 🌍</label>
              <select
                name="language"
                value={formData.language}
                onChange={handleChange}
                className="input-field"
              >
                <option value="English">English</option>
                <option value="Spanish">Spanish (Español)</option>
                <option value="French">French (Français)</option>
                <option value="German">German (Deutsch)</option>
                <option value="Italian">Italian (Italiano)</option>
                <option value="Portuguese">Portuguese (Português)</option>
                <option value="Dutch">Dutch (Nederlands)</option>
                <option value="Polish">Polish (Polski)</option>
                <option value="Russian">Russian (Русский)</option>
                <option value="Arabic">Arabic (العربية)</option>
                <option value="Hindi">Hindi (हिन्दी)</option>
                <option value="Mandarin">Mandarin (中文)</option>
                <option value="Japanese">Japanese (日本語)</option>
                <option value="Korean">Korean (한국어)</option>
                <option value="Turkish">Turkish (Türkçe)</option>
                <option value="Swedish">Swedish (Svenska)</option>
                <option value="Danish">Danish (Dansk)</option>
                <option value="Norwegian">Norwegian (Norsk)</option>
                <option value="Finnish">Finnish (Suomi)</option>
                <option value="Greek">Greek (Ελληνικά)</option>
                <option value="Czech">Czech (Čeština)</option>
                <option value="Romanian">Romanian (Română)</option>
                <option value="Hungarian">Hungarian (Magyar)</option>
                <option value="Ukrainian">Ukrainian (Українська)</option>
                <option value="Vietnamese">Vietnamese (Tiếng Việt)</option>
                <option value="Thai">Thai (ไทย)</option>
                <option value="Indonesian">Indonesian (Bahasa Indonesia)</option>
                <option value="Malay">Malay (Bahasa Melayu)</option>
                <option value="Tagalog">Tagalog (Filipino)</option>
                <option value="Hebrew">Hebrew (עברית)</option>
                <option value="Bengali">Bengali (বাংলা)</option>
                <option value="Tamil">Tamil (தமிழ்)</option>
                <option value="Urdu">Urdu (اردو)</option>
                <option value="Persian">Persian (فارسی)</option>
                <option value="Swahili">Swahili (Kiswahili)</option>
              </select>
              <p className="text-sm text-gray-500 mt-1">
                Santa speaks 71 languages! Select your preferred language.
              </p>
            </div>

            {/* Encouragement */}
            <div>
              <label className="label">What encouragement do they need?</label>
              <textarea
                name="encouragement"
                value={formData.encouragement}
                onChange={handleChange}
                className="input-field"
                rows="3"
                placeholder="e.g., struggling with reading, being kind to siblings, trying their best..."
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Sending to Santa...' : '🎁 Request Free Video'}
            </button>

            <p className="text-sm text-gray-500 text-center mt-4">
              Limited to 3 videos per family per season
            </p>
          </form>
        </div>

        {/* Our Other Projects */}
        <div className="card mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">
            Our Other Projects 🚀
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <a 
              href="https://www.spicylister.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="border-l-4 border-red-500 bg-gray-50 p-6 rounded hover:shadow-lg transition-shadow"
            >
              <h3 className="text-xl font-bold text-gray-800 mb-2">SpicyLister</h3>
              <p className="text-gray-600">
                Automated listing tool for online marketplaces
              </p>
            </a>

            <a 
              href="https://docstrange.netlify.app" 
              target="_blank" 
              rel="noopener noreferrer"
              className="border-l-4 border-orange-500 bg-gray-50 p-6 rounded hover:shadow-lg transition-shadow"
            >
              <h3 className="text-xl font-bold text-gray-800 mb-2">Doc Strange</h3>
              <p className="text-gray-600">
                Magic and mystery with Doc Strange
              </p>
            </a>

            <a 
              href="https://thestrangemoleshow-votegreen.netlify.app" 
              target="_blank" 
              rel="noopener noreferrer"
              className="border-l-4 border-teal-500 bg-gray-50 p-6 rounded hover:shadow-lg transition-shadow"
            >
              <h3 className="text-xl font-bold text-gray-800 mb-2">The Strange Mole Show</h3>
              <p className="text-gray-600">
                Vote Green with The Strange Mole Show
              </p>
            </a>

            <a 
              href="https://entertaincms.netlify.app" 
              target="_blank" 
              rel="noopener noreferrer"
              className="border-l-4 border-purple-500 bg-gray-50 p-6 rounded hover:shadow-lg transition-shadow"
            >
              <h3 className="text-xl font-bold text-gray-800 mb-2">EntertainCMS Community</h3>
              <p className="text-gray-600">
                Content management for entertainers
              </p>
            </a>

            <a 
              href="https://chrisptee-entertainments.netlify.app" 
              target="_blank" 
              rel="noopener noreferrer"
              className="border-l-4 border-blue-500 bg-gray-50 p-6 rounded hover:shadow-lg transition-shadow"
            >
              <h3 className="text-xl font-bold text-gray-800 mb-2">Chris P Tee Entertainments</h3>
              <p className="text-gray-600">
                Professional magic and entertainment services
              </p>
            </a>

            <a 
              href="https://www.buymeacoffee.com/chrispteemagician" 
              target="_blank" 
              rel="noopener noreferrer"
              className="border-l-4 border-yellow-500 bg-gray-50 p-6 rounded hover:shadow-lg transition-shadow"
            >
              <h3 className="text-xl font-bold text-gray-800 mb-2">Buy Me a Coffee</h3>
              <p className="text-gray-600">
                Support the magic with a coffee donation
              </p>
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center py-8 border-t border-gray-300">
          <p className="text-gray-700 mb-4 font-medium">
            Created with 💚 by Chris P Tee - Magic Circle Magician
          </p>
          <p className="text-sm text-gray-600 mb-4">
            Free forever. Donations welcome but never required.
          </p>
          <div className="flex justify-center gap-6 text-sm">
            <a href="mailto:chris@chrisptee.co.uk" className="text-blue-600 hover:underline">
              Contact
            </a>
              <a href="https://www.ko-fi.com/zoom" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                Ko-fi
              </a>
              <a href="https://www.buymeacoffee.com/chrispteemagician" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                Buy Me a Coffee
              </a>
          </div>
          <p className="text-xs text-gray-500 mt-6">
            © {new Date().getFullYear()} DnB Santa. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  )
}
