import { useRoute } from 'wouter'

export default function Confirmation() {
  const [, params] = useRoute('/confirmation/:id')
  const requestId = params?.id

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-red-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Success Message */}
        <div className="card text-center mb-8">
          <div className="text-6xl mb-4">✨</div>
          <h1 className="text-3xl font-bold text-dnb-green mb-4">
            Your request has been received!
          </h1>
          <p className="text-lg text-gray-700 mb-6">
            Chris is personally creating your magical video!
          </p>

          <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
            <p className="text-gray-800 mb-4">
              📧 You'll receive an email when your personalized video is ready!
            </p>
            <p className="text-gray-600 mb-2">
              ⏱️ Usually takes: 3-7 days
            </p>
            <p className="text-gray-600 mb-4">
              🎅 Each video is personally created by Chris P Tee with care and attention to detail!
            </p>
            <p className="text-gray-600">
              💚 While you wait, consider sharing DnB Santa with friends who might need some Christmas magic!
            </p>
          </div>

          {requestId && (
            <p className="text-sm text-gray-500">
              Request ID: {requestId}
            </p>
          )}
        </div>

        {/* Donation Section */}
        <div className="card bg-red-50 border-2 border-dnb-red">
          <h2 className="text-2xl font-bold text-dnb-red mb-4 text-center">
            💚 Love the Magic? Help Spread It!
          </h2>
          <p className="text-gray-700 mb-6 text-center">
            If you enjoyed the video, consider supporting Chris's work with a coffee donation
            <span className="font-semibold"> (only if you can afford it!)</span>
          </p>

          <div className="space-y-3">
            <a
              href="https://www.buymeacoffee.com/chrispteemagician"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full bg-yellow-400 hover:bg-yellow-500 text-gray-900 font-semibold py-3 px-6 rounded-lg text-center transition-colors duration-200"
            >
              ☕ Buy Me a Coffee
            </a>
            <a
              href="https://www.ko-fi.com/zoom"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-6 rounded-lg text-center transition-colors duration-200"
            >
              💙 Support on Ko-fi
            </a>
          </div>

          <p className="text-sm text-gray-600 text-center mt-4">
            Your support helps Chris create more free magic for families in need 🎅✨
          </p>
        </div>

        {/* Back Home */}
        <div className="text-center mt-8">
          <a
            href="/"
            className="inline-block bg-dnb-green hover:bg-green-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors duration-200"
          >
            🏠 Back to Home
          </a>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 text-gray-600">
          <p className="text-sm">
            Made with 💚 by Chris P Tee - Magic Circle Magician
          </p>
        </div>
      </div>
    </div>
  )
}
