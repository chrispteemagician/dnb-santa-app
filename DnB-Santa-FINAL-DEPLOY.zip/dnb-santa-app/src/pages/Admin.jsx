import { useState, useEffect } from 'react'
import { supabaseAdmin } from '../lib/supabase'

// CHANGE THIS PASSWORD TO YOUR OWN!
const ADMIN_PASSWORD = 'DnBSanta2024!'

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [passwordInput, setPasswordInput] = useState('')
  const [passwordError, setPasswordError] = useState('')
  
  const [requests, setRequests] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('pending')
  const [selectedRequest, setSelectedRequest] = useState(null)
  const [videoUrl, setVideoUrl] = useState('')
  const [stats, setStats] = useState({ total: 0, pending: 0, completed: 0 })
  const [generatingVideo, setGeneratingVideo] = useState(null)
  
  // Detail modal state
  const [detailModalOpen, setDetailModalOpen] = useState(false)
  const [editingRequest, setEditingRequest] = useState(null)
  const [editForm, setEditForm] = useState({})
  const [saving, setSaving] = useState(false)

  // Bonus video state
  const [bonusModalOpen, setBonusModalOpen] = useState(false)
  const [bonusRecipientName, setBonusRecipientName] = useState('')
  const [bonusChildName, setBonusChildName] = useState('')

  // Check if already authenticated (stored in sessionStorage)
  useEffect(() => {
    const auth = sessionStorage.getItem('dnb_admin_auth')
    if (auth === 'true') {
      setIsAuthenticated(true)
    }
  }, [])

  // Load requests when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      loadRequests()
    }
  }, [filter, isAuthenticated])

  const handleLogin = (e) => {
    e.preventDefault()
    if (passwordInput === ADMIN_PASSWORD) {
      setIsAuthenticated(true)
      sessionStorage.setItem('dnb_admin_auth', 'true')
      setPasswordError('')
    } else {
      setPasswordError('Incorrect password. Try again.')
      setPasswordInput('')
    }
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    sessionStorage.removeItem('dnb_admin_auth')
  }

  const loadRequests = async () => {
    setLoading(true)
    try {
      let query = supabaseAdmin
        .from('video_requests')
        .select('*')
        .order('created_at', { ascending: false })

      if (filter !== 'all') {
        query = query.eq('status', filter)
      }

      const { data, error } = await query

      if (error) throw error
      setRequests(data || [])

      // Calculate stats
      const allRequests = await supabaseAdmin
        .from('video_requests')
        .select('status')

      if (allRequests.data) {
        setStats({
          total: allRequests.data.length,
          pending: allRequests.data.filter(r => r.status === 'pending').length,
          completed: allRequests.data.filter(r => r.status === 'completed').length
        })
      }
    } catch (err) {
      console.error('Error loading requests:', err)
    } finally {
      setLoading(false)
    }
  }

  const updateStatus = async (id, newStatus) => {
    try {
      const { error } = await supabaseAdmin
        .from('video_requests')
        .update({ status: newStatus })
        .eq('id', id)

      if (error) throw error
      loadRequests()
    } catch (err) {
      console.error('Error updating status:', err)
    }
  }

  const generateVideo = async (requestId) => {
    setGeneratingVideo(requestId)
    try {
      const response = await fetch('/.netlify/functions/generate-video-background', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId })
      })

      if (!response.ok) throw new Error('Failed to start video generation')

      // Update status to processing
      await updateStatus(requestId, 'processing')
      
      alert('🎅 Video generation started! This will take 3-5 minutes. The page will refresh when complete.')
      
      // Poll for completion
      const checkInterval = setInterval(async () => {
        const { data } = await supabaseAdmin
          .from('video_requests')
          .select('status')
          .eq('id', requestId)
          .single()
        
        if (data && data.status === 'completed') {
          clearInterval(checkInterval)
          setGeneratingVideo(null)
          loadRequests()
          alert('✅ Video generation complete!')
        }
      }, 10000) // Check every 10 seconds
      
    } catch (err) {
      console.error('Error generating video:', err)
      alert('❌ Failed to start video generation. Check console for details.')
      setGeneratingVideo(null)
    }
  }

  const generateBonusVideo = async () => {
    if (!bonusRecipientName || !bonusChildName) {
      alert('Please enter both names!')
      return
    }

    setGeneratingVideo('bonus')
    try {
      const response = await fetch('/.netlify/functions/generate-video-background', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          isBonus: true,
          childName: bonusChildName,
          recipientName: bonusRecipientName,
          parentEmail: editingRequest.parent_email
        })
      })

      if (!response.ok) throw new Error('Failed to start bonus video generation')
      
      alert('🎅 Bonus video generation started! This will take 3-5 minutes.')
      setBonusModalOpen(false)
      setBonusRecipientName('')
      setBonusChildName('')
      setGeneratingVideo(null)
      
    } catch (err) {
      console.error('Error generating bonus video:', err)
      alert('❌ Failed to start bonus video generation. Check console for details.')
      setGeneratingVideo(null)
    }
  }

  const updateVideoUrl = async (id) => {
    try {
      const { error } = await supabaseAdmin
        .from('video_requests')
        .update({ 
          video_url: videoUrl,
          status: 'completed'
        })
        .eq('id', id)

      if (error) throw error
      setVideoUrl('')
      setSelectedRequest(null)
      loadRequests()
    } catch (err) {
      console.error('Error updating video URL:', err)
    }
  }

  const openDetailModal = (request) => {
    setEditingRequest(request)
    setEditForm({
      child_name: request.child_name || '',
      child_age: request.child_age || '',
      parent_name: request.parent_name || '',
      parent_email: request.parent_email || '',
      interests: request.interests || '',
      wish_list: request.wish_list || '',
      encouragement: request.encouragement || '',
      language: request.language || 'English',
      admin_notes: request.admin_notes || '',
      script_used: request.script_used || '',
      video_url: request.video_url || '',
      status: request.status || 'pending'
    })
    setDetailModalOpen(true)
  }

  const saveRequestChanges = async () => {
    setSaving(true)
    try {
      const { error } = await supabaseAdmin
        .from('video_requests')
        .update(editForm)
        .eq('id', editingRequest.id)

      if (error) throw error
      
      alert('✅ Changes saved successfully!')
      setDetailModalOpen(false)
      setEditingRequest(null)
      loadRequests()
    } catch (err) {
      console.error('Error saving changes:', err)
      alert('❌ Failed to save changes. Check console for details.')
    } finally {
      setSaving(false)
    }
  }

  // Login Screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-red-50 to-green-50 flex items-center justify-center px-4">
        <div className="card max-w-md w-full">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-dnb-red mb-2">🔒 Admin Login</h1>
            <p className="text-gray-600">Enter password to access dashboard</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="label">Password</label>
              <input
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                className="input-field"
                placeholder="Enter admin password"
                autoFocus
              />
            </div>

            {passwordError && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                {passwordError}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-dnb-red hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
            >
              Login
            </button>
          </form>

          <div className="mt-6 text-center">
            <a href="/" className="text-dnb-green hover:underline text-sm">
              ← Back to Home
            </a>
          </div>

          <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-gray-700">
              <strong>⚠️ Security Note:</strong> To change the password, edit the <code>ADMIN_PASSWORD</code> constant in <code>src/pages/Admin.jsx</code>
            </p>
          </div>
        </div>
      </div>
    )
  }

  // Admin Dashboard (only shown when authenticated)
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-600 to-green-600 text-white py-6 px-4 sticky top-0 z-10 shadow-lg">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">🎅 DnB Santa Admin</h1>
            <p className="text-sm opacity-90">Manage video requests</p>
          </div>
          <button
            onClick={handleLogout}
            className="bg-white text-red-600 px-4 py-2 rounded-lg font-semibold hover:bg-red-50 transition-colors"
          >
            Logout
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="card bg-blue-50">
            <div className="text-3xl font-bold text-blue-600">{stats.total}</div>
            <div className="text-gray-600">Total Requests</div>
          </div>
          <div className="card bg-yellow-50">
            <div className="text-3xl font-bold text-yellow-600">{stats.pending}</div>
            <div className="text-gray-600">Pending</div>
          </div>
          <div className="card bg-green-50">
            <div className="text-3xl font-bold text-green-600">{stats.completed}</div>
            <div className="text-gray-600">Completed</div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-6 overflow-x-auto">
          {['all', 'pending', 'processing', 'completed', 'failed'].map(status => (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={`px-4 py-2 rounded-lg font-semibold whitespace-nowrap ${
                filter === status
                  ? 'bg-dnb-red text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </button>
          ))}
        </div>

        {/* Requests List */}
        {loading ? (
          <div className="text-center py-12">
            <div className="text-2xl">Loading...</div>
          </div>
        ) : requests.length === 0 ? (
          <div className="card text-center py-12">
            <div className="text-6xl mb-4">📭</div>
            <div className="text-xl text-gray-600">No requests found</div>
          </div>
        ) : (
          <div className="space-y-4">
            {requests.map(request => (
              <div 
                key={request.id} 
                className="card hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => openDetailModal(request)}
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-gray-800">
                      {request.child_name} ({request.child_age || 'Age not provided'})
                    </h3>
                    <p className="text-gray-600">{request.parent_name} - {request.parent_email}</p>
                    {request.tier && (
                      <span className={`inline-block px-3 py-1 rounded-full text-sm font-semibold mt-2 ${
                        request.tier === 'value' ? 'bg-blue-100 text-blue-700' :
                        request.tier === 'business' ? 'bg-amber-100 text-amber-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {request.tier.toUpperCase()} TIER
                      </span>
                    )}
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                    request.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                    request.status === 'processing' ? 'bg-blue-100 text-blue-700' :
                    request.status === 'completed' ? 'bg-green-100 text-green-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {request.status}
                  </span>
                </div>

                <div className="space-y-2 mb-4">
                  {request.interests && (
                    <p className="text-sm"><strong>Interests:</strong> {request.interests.substring(0, 100)}{request.interests.length > 100 ? '...' : ''}</p>
                  )}
                  {request.admin_notes && (
                    <p className="text-sm text-purple-600"><strong>📝 Notes:</strong> {request.admin_notes.substring(0, 80)}{request.admin_notes.length > 80 ? '...' : ''}</p>
                  )}
                </div>

                <div className="text-xs text-gray-500">
                  Click to view full details and edit
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Detail/Edit Modal */}
      {detailModalOpen && editingRequest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="card max-w-4xl w-full my-8 max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white pb-4 border-b mb-4">
              <h2 className="text-3xl font-bold text-gray-800">
                📋 Request Details - {editingRequest.child_name}
              </h2>
              <p className="text-sm text-gray-500">ID: {editingRequest.id} | Created: {new Date(editingRequest.created_at).toLocaleString()}</p>
            </div>

            <div className="space-y-6">
              {/* Child Info */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Child's Name *</label>
                  <input
                    type="text"
                    value={editForm.child_name}
                    onChange={(e) => setEditForm({...editForm, child_name: e.target.value})}
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="label">Child's Age</label>
                  <input
                    type="number"
                    value={editForm.child_age}
                    onChange={(e) => setEditForm({...editForm, child_age: e.target.value})}
                    className="input-field"
                  />
                </div>
              </div>

              {/* Parent Info */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Parent Name</label>
                  <input
                    type="text"
                    value={editForm.parent_name}
                    onChange={(e) => setEditForm({...editForm, parent_name: e.target.value})}
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="label">Parent Email *</label>
                  <input
                    type="email"
                    value={editForm.parent_email}
                    onChange={(e) => setEditForm({...editForm, parent_email: e.target.value})}
                    className="input-field"
                  />
                </div>
              </div>

              {/* Language & Status */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Language</label>
                  <input
                    type="text"
                    value={editForm.language}
                    onChange={(e) => setEditForm({...editForm, language: e.target.value})}
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="label">Status</label>
                  <select
                    value={editForm.status}
                    onChange={(e) => setEditForm({...editForm, status: e.target.value})}
                    className="input-field"
                  >
                    <option value="pending">Pending</option>
                    <option value="processing">Processing</option>
                    <option value="completed">Completed</option>
                    <option value="failed">Failed</option>
                  </select>
                </div>
              </div>

              {/* Interests */}
              <div>
                <label className="label">Interests</label>
                <textarea
                  value={editForm.interests}
                  onChange={(e) => setEditForm({...editForm, interests: e.target.value})}
                  className="input-field"
                  rows="3"
                />
              </div>

              {/* Wish List */}
              <div>
                <label className="label">Wish List</label>
                <textarea
                  value={editForm.wish_list}
                  onChange={(e) => setEditForm({...editForm, wish_list: e.target.value})}
                  className="input-field"
                  rows="3"
                />
              </div>

              {/* Encouragement */}
              <div>
                <label className="label">Encouragement</label>
                <textarea
                  value={editForm.encouragement}
                  onChange={(e) => setEditForm({...editForm, encouragement: e.target.value})}
                  className="input-field"
                  rows="3"
                />
              </div>

              {/* Video URL */}
              <div>
                <label className="label">Video URL</label>
                <input
                  type="url"
                  value={editForm.video_url}
                  onChange={(e) => setEditForm({...editForm, video_url: e.target.value})}
                  className="input-field"
                  placeholder="https://..."
                />
                {editForm.video_url && (
                  <a 
                    href={editForm.video_url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-sm text-blue-600 hover:underline mt-1 inline-block"
                  >
                    🎥 View Video
                  </a>
                )}
              </div>

              {/* Script Used */}
              <div>
                <label className="label">📜 Script Used (for reference)</label>
                <textarea
                  value={editForm.script_used}
                  onChange={(e) => setEditForm({...editForm, script_used: e.target.value})}
                  className="input-field"
                  rows="4"
                  placeholder="Save the script here so you don't repeat it next year..."
                />
              </div>

              {/* Admin Notes */}
              <div>
                <label className="label">📝 Admin Notes (private)</label>
                <textarea
                  value={editForm.admin_notes}
                  onChange={(e) => setEditForm({...editForm, admin_notes: e.target.value})}
                  className="input-field"
                  rows="4"
                  placeholder="Your private notes about this request..."
                />
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-3 pt-4 border-t">
                <button
                  onClick={saveRequestChanges}
                  disabled={saving}
                  className="px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-bold rounded-lg disabled:opacity-50"
                >
                  {saving ? 'Saving...' : '💾 Save Changes'}
                </button>

                {editingRequest.status === 'pending' && (
                  <>
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        setDetailModalOpen(false)
                        generateVideo(editingRequest.id)
                      }}
                      disabled={generatingVideo === editingRequest.id}
                      className="px-6 py-3 bg-purple-500 hover:bg-purple-600 text-white font-bold rounded-lg disabled:opacity-50"
                    >
                      {generatingVideo === editingRequest.id ? '⏳ Generating...' : '🤖 Generate Video'}
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        updateStatus(editingRequest.id, 'processing')
                        setDetailModalOpen(false)
                      }}
                      className="px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-lg"
                    >
                      Manual Process
                    </button>
                  </>
                )}

                <button
                  onClick={() => {
                    setBonusChildName(editingRequest.child_name)
                    setBonusModalOpen(true)
                  }}
                  className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-lg"
                >
                  🎁 Generate Bonus Video
                </button>

                <button
                  onClick={() => navigator.clipboard.writeText(editingRequest.parent_email)}
                  className="px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold rounded-lg"
                >
                  📋 Copy Email
                </button>

                <button
                  onClick={() => {
                    setDetailModalOpen(false)
                    setEditingRequest(null)
                  }}
                  className="px-6 py-3 bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold rounded-lg ml-auto"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bonus Video Modal */}
      {bonusModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="card max-w-lg w-full">
            <h3 className="text-2xl font-bold mb-4">🎁 Generate Bonus Video</h3>
            <p className="text-gray-600 mb-4">
              This will create a special friend greeting video with the message:
            </p>
            <div className="bg-amber-50 border-2 border-amber-300 rounded-lg p-4 mb-4">
              <p className="text-sm italic">
                "Ho ho ho! Hello there, I'm DnB Santa and my good friend <strong>{bonusChildName || '[CHILD NAME]'}</strong> says 
                You are a Wonderful Friend and asked me to wish <strong>{bonusRecipientName || '[FRIEND NAME]'}</strong> a very Merry Christmas and a Happy New Year!"
              </p>
            </div>
            
            <div className="space-y-4 mb-4">
              <div>
                <label className="label">Child's Name (who is sending)</label>
                <input
                  type="text"
                  value={bonusChildName}
                  onChange={(e) => setBonusChildName(e.target.value)}
                  placeholder="e.g., Tommy"
                  className="input-field"
                />
              </div>
              <div>
                <label className="label">Friend's Name (who is receiving)</label>
                <input
                  type="text"
                  value={bonusRecipientName}
                  onChange={(e) => setBonusRecipientName(e.target.value)}
                  placeholder="e.g., Sarah"
                  className="input-field"
                />
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={generateBonusVideo}
                disabled={!bonusRecipientName || !bonusChildName || generatingVideo === 'bonus'}
                className="flex-1 bg-amber-500 hover:bg-amber-600 text-white font-bold py-3 px-6 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {generatingVideo === 'bonus' ? '⏳ Generating...' : '🎁 Generate Bonus Video'}
              </button>
              <button
                onClick={() => {
                  setBonusModalOpen(false)
                  setBonusRecipientName('')
                  setBonusChildName('')
                }}
                className="px-6 py-3 bg-gray-300 hover:bg-gray-400 rounded-lg font-semibold"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
