import { Route, Switch } from 'wouter'
import Home from './pages/Home'
import Confirmation from './pages/Confirmation'
import Admin from './pages/Admin'
import ValueOrder from './pages/ValueOrder'
import BusinessOrder from './pages/BusinessOrder'

function App() {
  return (
    <div className="min-h-screen">
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/confirmation/:id" component={Confirmation} />
        <Route path="/admin" component={Admin} />
        <Route path="/value-order" component={ValueOrder} />
        <Route path="/business-order" component={BusinessOrder} />
        <Route>
          <div className="flex items-center justify-center min-h-screen">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-dnb-red mb-4">404</h1>
              <p className="text-gray-600">Page not found</p>
              <a href="/" className="text-dnb-green hover:underline mt-4 inline-block">
                Go home
              </a>
            </div>
          </div>
        </Route>
      </Switch>
    </div>
  )
}

export default App
