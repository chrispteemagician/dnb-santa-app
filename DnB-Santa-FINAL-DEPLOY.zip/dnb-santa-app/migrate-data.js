// Data Migration Script: TiDB → Supabase
// Run this once to migrate existing video requests

import { createClient } from '@supabase/supabase-js'
import mysql from 'mysql2/promise'

const supabaseUrl = 'https://lauswgjnlghltkbwszgx.supabase.co'
const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxhdXN3Z2pubGdobHRrYndzemd4Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MjcxMjI1NCwiZXhwIjoyMDc4Mjg4MjU0fQ.mRsppl_fXU3m0FLu4HCvWSBIghmY5ZjpSfaXYKsQgX0'

const supabase = createClient(supabaseUrl, supabaseServiceKey)

// TiDB connection string from environment
const tidbUrl = process.env.DATABASE_URL || 'mysql://4SXwSh2hDXpXEtM.root:IjcJMrGWdBtxMjRD@gateway02.us-east-1.prod.aws.tidbcloud.com:4000/test?ssl={"rejectUnauthorized":true}'

async function migrate() {
  console.log('🔄 Starting data migration from TiDB to Supabase...\n')

  try {
    // Connect to TiDB
    console.log('📡 Connecting to TiDB...')
    const connection = await mysql.createConnection(tidbUrl)
    console.log('✅ Connected to TiDB\n')

    // Fetch all video requests from TiDB
    console.log('📥 Fetching video requests from TiDB...')
    const [rows] = await connection.execute('SELECT * FROM aiVideoRequests ORDER BY id')
    console.log(`✅ Found ${rows.length} requests\n`)

    if (rows.length === 0) {
      console.log('No data to migrate!')
      await connection.end()
      return
    }

    // Transform and insert into Supabase
    console.log('📤 Migrating to Supabase...')
    let successCount = 0
    let errorCount = 0

    for (const row of rows) {
      try {
        const { error } = await supabase
          .from('video_requests')
          .insert([{
            child_name: row.childName,
            child_age: row.childAge,
            parent_name: row.parentName,
            parent_email: row.parentEmail,
            interests: row.interests,
            wish_list: row.wishList,
            encouragement: row.encouragement,
            video_url: row.videoUrl,
            status: row.status || 'pending',
            created_at: row.createdAt,
            updated_at: row.updatedAt
          }])

        if (error) {
          console.error(`❌ Error migrating request ${row.id}:`, error.message)
          errorCount++
        } else {
          console.log(`✅ Migrated: ${row.childName} (${row.parentEmail})`)
          successCount++
        }
      } catch (err) {
        console.error(`❌ Error migrating request ${row.id}:`, err.message)
        errorCount++
      }
    }

    console.log(`\n📊 Migration complete!`)
    console.log(`   ✅ Success: ${successCount}`)
    console.log(`   ❌ Errors: ${errorCount}`)

    await connection.end()
    console.log('\n🎉 Done!')

  } catch (error) {
    console.error('❌ Migration failed:', error)
    process.exit(1)
  }
}

migrate()
