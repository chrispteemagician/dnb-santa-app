import Anthropic from '@anthropic-ai/sdk';

/**
 * DnB Santa Script Generator
 * Generates personalized scripts in Chris P Tee's authentic DnB Santa voice
 */

export class ScriptGenerator {
  constructor(apiKey) {
    this.client = new Anthropic({ apiKey });
  }

  /**
   * Generate a bonus friend greeting video script
   * @param {string} childName - Name of child sending the greeting
   * @param {string} recipientName - Name of friend receiving the greeting
   * @returns {Promise<string>} - Generated bonus script
   */
  async generateBonusScript(childName, recipientName) {
    const script = `Ho ho ho! Hello there, I'm DnB Santa and my good friend ${childName} says You are a Wonderful Friend and asked me to wish ${recipientName} a very Merry Christmas and a Happy New Year! Ho ho ho! BIG UP yourself, ${recipientName}! RESPECT!`;
    return script;
  }

  /**
   * Generate a personalized DnB Santa script
   * @param {Object} request - Video request details from Supabase
   * @returns {Promise<string>} - Generated script
   */
  async generateScript(request) {
    const {
      child_name,
      child_age,
      interests,
      wish_list,
      encouragement,
      language = 'English'
    } = request;

    const prompt = this.buildPrompt(child_name, child_age, interests, wish_list, encouragement, language);

    try {
      const message = await this.client.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: prompt
        }]
      });

      return message.content[0].text;
    } catch (error) {
      console.error('Error generating script:', error);
      throw new Error(`Script generation failed: ${error.message}`);
    }
  }

  /**
   * Build the prompt for Claude to generate script in DnB Santa voice
   */
  buildPrompt(childName, childAge, interests, wishList, encouragement, language) {
    return `You are writing a 30-second personalized Christmas video script for DnB Santa.

CRITICAL VOICE GUIDELINES:
- You are Chris P Tee, a Magic Circle magician with 30+ years experience
- You speak as DnB Santa - warm grandfatherly Santa + British urban DnB culture
- Balance: 70% traditional Santa warmth, 30% DnB energy
- Use DnB lingo sparingly and naturally: "BIG UP", "PROPER", "HEAVYWEIGHT", "FIRE", "VIBES"
- Always authentic, never forced
- Keep it warm, encouraging, and genuinely caring

DnB SANTA LINGO (use 2-3 max):
- "BIG UP" = greeting/respect
- "PROPER" = really/genuinely  
- "HEAVYWEIGHT" = serious/important
- "FIRE" = excellent/amazing
- "VIBES" = feeling/energy
- "CLOCKED IT" = noticed/saw
- "MASSIVE" = big/impressive

SCRIPT STRUCTURE (30 seconds):
1. Opening (5 sec): "Ho ho ho! BIG UP! Is that ${childName}? ${childName.toUpperCase()}!"
2. Personal Achievement Recognition (10 sec): Mention their interests/what they're working on
3. Encouragement (8 sec): Address what they need help with
4. Wish List Acknowledgment (5 sec): Briefly mention their wishes
5. Closing (2 sec): "Ho ho ho! RESPECT!"

CHILD DETAILS:
- Name: ${childName}
- Age: ${childAge || 'unknown'}
- Interests: ${interests || 'general interests'}
- Wish List: ${wishList || 'surprises'}
- Needs Encouragement With: ${encouragement || 'being amazing'}
- Language: ${language}

IMPORTANT RULES:
- Maximum 30 seconds when spoken (roughly 75-85 words)
- Be SPECIFIC about their interests (don't just list them)
- Show you GENUINELY know them ("I saw you...", "I heard you...")
- Keep encouragement POSITIVE and achievable
- End with "Ho ho ho! RESPECT!" or "Ho ho ho! BIG UP yourself!"
- NO generic filler - every word must be personal to ${childName}
- Write ONLY the script - no stage directions, no notes, just what Santa says

Example opening: "Ho ho ho! BIG UP! Is that ${childName}? ${childName.toUpperCase()}! Oh my goodness, I've been SO excited to talk to you!"

Now write the COMPLETE 30-second script for ${childName}:`;
  }

  /**
   * Validate script length (should be ~30 seconds when spoken)
   * @param {string} script 
   * @returns {boolean}
   */
  validateScriptLength(script) {
    const wordCount = script.split(/\s+/).length;
    // 30 seconds ≈ 75-85 words at conversational pace
    return wordCount >= 60 && wordCount <= 100;
  }

  /**
   * Generate script with retry if length is wrong
   */
  async generateValidatedScript(request, maxRetries = 2) {
    let attempts = 0;
    
    while (attempts < maxRetries) {
      const script = await this.generateScript(request);
      
      if (this.validateScriptLength(script)) {
        console.log(`✅ Script generated successfully (${script.split(/\s+/).length} words)`);
        return script;
      }
      
      console.log(`⚠️ Script length invalid, retrying... (attempt ${attempts + 1})`);
      attempts++;
    }
    
    // If still invalid after retries, return anyway with warning
    const finalScript = await this.generateScript(request);
    console.warn(`⚠️ Script may be wrong length: ${finalScript.split(/\s+/).length} words`);
    return finalScript;
  }
}

// Example usage (for testing)
export async function testScriptGenerator() {
  const generator = new ScriptGenerator(process.env.ANTHROPIC_API_KEY);
  
  const testRequest = {
    child_name: 'Emma',
    child_age: 7,
    interests: 'piano, helping her little brother Jack',
    wish_list: '120 colour art set, horse books',
    encouragement: 'tidying her room without being asked',
    language: 'English'
  };
  
  console.log('🎅 Generating test script for Emma...\n');
  const script = await generator.generateValidatedScript(testRequest);
  console.log('📝 GENERATED SCRIPT:\n');
  console.log(script);
  console.log('\n✅ Script generation test complete!');
}
