import fetch from 'node-fetch';
import FormData from 'form-data';
import fs from 'fs';

/**
 * VisionStory Video Generator
 * Creates talking avatar videos from audio files
 */

export class VideoGenerator {
  constructor(apiKey, avatarId) {
    this.apiKey = apiKey;
    this.avatarId = avatarId;
    this.baseUrl = 'https://www.visionstory.ai/api';
  }

  /**
   * Create video from audio file
   * @param {Buffer|string} audioSource - Audio buffer or file path
   * @param {Object} options - Video generation options
   * @returns {Promise<string>} - Video task ID
   */
  async createVideo(audioSource, options = {}) {
    const {
      resolution = '720', // '480' or '720'
      model = 'V-Talk', // 'V-Talk' or 'V-Character'
      aspectRatio = '16:9' // '9:16', '16:9', '1:1'
    } = options;

    try {
      console.log(`🎬 Creating video with VisionStory (${resolution}p ${model})...`);

      // NOTE: This is a placeholder implementation
      // You'll need to check VisionStory's actual API documentation
      // at https://www.visionstory.ai/openapi/docs for exact endpoints

      const formData = new FormData();
      
      // If audioSource is a buffer, convert to stream
      if (Buffer.isBuffer(audioSource)) {
        formData.append('audio', audioSource, {
          filename: 'audio.mp3',
          contentType: 'audio/mpeg'
        });
      } else {
        // If it's a file path
        formData.append('audio', fs.createReadStream(audioSource));
      }

      formData.append('avatar_id', this.avatarId);
      formData.append('resolution', resolution);
      formData.append('model', model);
      formData.append('aspect_ratio', aspectRatio);

      const response = await fetch(`${this.baseUrl}/v1/video/generate`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          ...formData.getHeaders()
        },
        body: formData
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`VisionStory API error: ${response.status} - ${error}`);
      }

      const data = await response.json();
      const taskId = data.task_id || data.id;
      
      console.log(`✅ Video task created: ${taskId}`);
      return taskId;
      
    } catch (error) {
      console.error('Error creating video:', error);
      throw new Error(`Video creation failed: ${error.message}`);
    }
  }

  /**
   * Check video generation status
   * @param {string} taskId 
   * @returns {Promise<Object>} - Task status and video URL if complete
   */
  async checkStatus(taskId) {
    try {
      const response = await fetch(`${this.baseUrl}/v1/video/status/${taskId}`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to check status: ${response.status}`);
      }

      const data = await response.json();
      return {
        status: data.status, // 'pending', 'processing', 'completed', 'failed'
        videoUrl: data.video_url,
        progress: data.progress
      };
      
    } catch (error) {
      console.error('Error checking video status:', error);
      throw error;
    }
  }

  /**
   * Wait for video to complete (with polling)
   * @param {string} taskId 
   * @param {number} maxWaitMinutes 
   * @returns {Promise<string>} - Video URL
   */
  async waitForVideo(taskId, maxWaitMinutes = 5) {
    const maxAttempts = maxWaitMinutes * 12; // Check every 5 seconds
    let attempts = 0;

    console.log(`⏳ Waiting for video generation to complete...`);

    while (attempts < maxAttempts) {
      const status = await this.checkStatus(taskId);

      if (status.status === 'completed') {
        console.log(`✅ Video completed! URL: ${status.videoUrl}`);
        return status.videoUrl;
      }

      if (status.status === 'failed') {
        throw new Error('Video generation failed');
      }

      // Still processing
      if (status.progress) {
        console.log(`⏳ Progress: ${status.progress}%`);
      }

      // Wait 5 seconds before checking again
      await new Promise(resolve => setTimeout(resolve, 5000));
      attempts++;
    }

    throw new Error('Video generation timed out');
  }

  /**
   * Download video from URL
   * @param {string} videoUrl 
   * @returns {Promise<Buffer>}
   */
  async downloadVideo(videoUrl) {
    try {
      console.log(`📥 Downloading video...`);
      
      const response = await fetch(videoUrl);
      
      if (!response.ok) {
        throw new Error(`Failed to download video: ${response.status}`);
      }

      const videoBuffer = await response.buffer();
      console.log(`✅ Video downloaded (${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB)`);
      
      return videoBuffer;
      
    } catch (error) {
      console.error('Error downloading video:', error);
      throw error;
    }
  }

  /**
   * Full workflow: create video and wait for completion
   * @param {Buffer|string} audioSource 
   * @param {Object} options 
   * @returns {Promise<Buffer>} - Video file as buffer
   */
  async generateCompleteVideo(audioSource, options = {}) {
    // Step 1: Create video task
    const taskId = await this.createVideo(audioSource, options);

    // Step 2: Wait for completion
    const videoUrl = await this.waitForVideo(taskId);

    // Step 3: Download video
    const videoBuffer = await this.downloadVideo(videoUrl);

    return videoBuffer;
  }

  /**
   * Get account credits remaining
   */
  async getCredits() {
    try {
      const response = await fetch(`${this.baseUrl}/v1/account/credits`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch credits: ${response.status}`);
      }

      const data = await response.json();
      console.log(`💳 VisionStory credits: ${data.credits}`);
      return data.credits;
      
    } catch (error) {
      console.error('Error fetching credits:', error);
      return null;
    }
  }
}

// Test function
export async function testVideoGenerator() {
  const generator = new VideoGenerator(
    process.env.VISIONSTORY_API_KEY,
    process.env.VISIONSTORY_AVATAR_ID
  );
  
  console.log('🎬 Testing VisionStory integration...\n');
  
  // Check credits
  await generator.getCredits();
  
  console.log('\n⚠️ Note: Full video generation test requires audio file');
  console.log('✅ VisionStory client initialized successfully!');
}

/**
 * Video cost calculator
 */
export function calculateVideoCost(durationSeconds, resolution = '720', model = 'V-Talk') {
  const segmentsNeeded = Math.ceil(durationSeconds / 15);
  
  let creditsPerSegment;
  if (resolution === '720' && model === 'V-Talk') {
    creditsPerSegment = 2;
  } else if (resolution === '480') {
    creditsPerSegment = 1;
  } else if (model === 'V-Character') {
    creditsPerSegment = 4; // Double the V-Talk cost
  } else {
    creditsPerSegment = 2; // Default
  }

  const totalCredits = segmentsNeeded * creditsPerSegment;
  
  return {
    duration: durationSeconds,
    resolution,
    model,
    segments: segmentsNeeded,
    creditsPerSegment,
    totalCredits,
    costUSD: (totalCredits * 0.10).toFixed(2) // Approximate based on Pro plan
  };
}
