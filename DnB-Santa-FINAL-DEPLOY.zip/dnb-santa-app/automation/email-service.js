import { Resend } from 'resend';

/**
 * Email Service
 * Sends beautiful emails to parents when their DnB Santa video is ready
 */

export class EmailService {
  constructor(apiKey, fromEmail = 'chris@chrisptee.co.uk', fromName = 'DnB Santa') {
    this.resend = new Resend(apiKey);
    this.fromEmail = fromEmail;
    this.fromName = fromName;
  }

  /**
   * Send bonus friend greeting video email
   * @param {Object} options - Email options
   * @returns {Promise<Object>} - Send result
   */
  async sendBonusVideoEmail(options) {
    const {
      parentEmail,
      childName,
      recipientName,
      videoUrl
    } = options;

    const htmlContent = this.generateBonusEmailHTML(childName, recipientName, videoUrl);

    try {
      console.log(`📧 Sending bonus video email to ${parentEmail}...`);

      const { data, error } = await this.resend.emails.send({
        from: `${this.fromName} <${this.fromEmail}>`,
        to: [parentEmail],
        subject: `🎁 Bonus Video from DnB Santa - ${childName}'s Friend Greeting!`,
        html: htmlContent,
        replyTo: this.fromEmail
      });

      if (error) throw error;

      console.log(`✅ Bonus video email sent successfully to ${parentEmail} (ID: ${data.id})`);

      return {
        success: true,
        emailId: data.id
      };

    } catch (error) {
      console.error('Error sending bonus video email:', error);
      throw new Error(`Bonus email failed: ${error.message}`);
    }
  }

  /**
   * Send video ready email to parent
   * @param {Object} options - Email options
   * @returns {Promise<Object>} - Send result
   */
  async sendVideoReadyEmail(options) {
    const {
      parentEmail,
      parentName,
      childName,
      videoUrl,
      requestId
    } = options;

    const htmlContent = this.generateEmailHTML(parentName, childName, videoUrl);

    try {
      console.log(`📧 Sending email to ${parentEmail}...`);

      const { data, error } = await this.resend.emails.send({
        from: `${this.fromName} <${this.fromEmail}>`,
        to: [parentEmail],
        subject: `🎅 ${childName}'s Personalized Christmas Video is Ready!`,
        html: htmlContent,
        replyTo: this.fromEmail
      });

      if (error) throw error;

      console.log(`✅ Email sent successfully to ${parentEmail} (ID: ${data.id})`);

      return {
        success: true,
        emailId: data.id
      };

    } catch (error) {
      console.error('Error sending email:', error);
      throw new Error(`Email failed: ${error.message}`);
    }
  }

  /**
   * Generate bonus video email HTML
   */
  generateBonusEmailHTML(childName, recipientName, videoUrl) {
    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bonus Video from DnB Santa!</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>
            <td style="padding: 20px 0;">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    
                    <!-- Header -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #f59e0b 0%, #dc2626 100%); padding: 40px 30px; text-align: center;">
                            <h1 style="color: #ffffff; margin: 0; font-size: 36px;">🎁 Ho Ho Ho!</h1>
                            <p style="color: #ffffff; margin: 15px 0 0 0; font-size: 20px; font-weight: bold;">
                                Bonus Friend Greeting Video!
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Main Content -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <p style="margin: 0 0 20px 0; font-size: 18px; color: #333333;">
                                Hi there,
                            </p>
                            
                            <p style="margin: 0 0 20px 0; font-size: 16px; line-height: 1.6; color: #333333;">
                                <strong>BIG UP!</strong> ${childName} wanted to send a special Christmas greeting to their friend ${recipientName}! 🎄
                            </p>
                            
                            <p style="margin: 0 0 30px 0; font-size: 16px; line-height: 1.6; color: #333333;">
                                This is a <strong>BONUS</strong> video - a friend greeting from DnB Santa! 🎅
                            </p>
                            
                            <!-- CTA Button -->
                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto 30px auto;">
                                <tr>
                                    <td style="background-color: #f59e0b; border-radius: 8px; text-align: center;">
                                        <a href="${videoUrl}" 
                                           style="display: inline-block; padding: 18px 40px; color: #ffffff; text-decoration: none; font-weight: bold; font-size: 18px;">
                                            🎁 Watch the Bonus Video
                                        </a>
                                    </td>
                                </tr>
                            </table>
                            
                            <p style="margin: 0 0 20px 0; font-size: 16px; line-height: 1.6; color: #333333;">
                                This is a special friend greeting video where DnB Santa delivers ${childName}'s Christmas wishes to ${recipientName}!
                            </p>
                            
                            <p style="margin: 0 0 20px 0; font-size: 16px; line-height: 1.6; color: #333333;">
                                Ho ho ho! RESPECT! 🎅💚
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f9fafb; padding: 30px; text-align: center; border-top: 1px solid #e5e7eb;">
                            <p style="margin: 0 0 10px 0; font-size: 16px; color: #333333; font-weight: bold;">
                                Ho ho ho! Merry Christmas! 🎄
                            </p>
                            <p style="margin: 0 0 15px 0; font-size: 14px; color: #666666;">
                                Made with love by DnB Santa<br>
                                Chris P Tee - Magic Circle Magician
                            </p>
                            <p style="margin: 0; font-size: 12px;">
                                <a href="https://dnbsanta.netlify.app" style="color: #dc2626; text-decoration: none;">
                                    dnbsanta.netlify.app
                                </a>
                            </p>
                        </td>
                    </tr>
                    
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
    `;
  }

  /**
   * Generate beautiful HTML email content
   */
  generateEmailHTML(parentName, childName, videoUrl) {
    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your DnB Santa Video is Ready!</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>
            <td style="padding: 20px 0;">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    
                    <!-- Header -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #dc2626 0%, #16a34a 100%); padding: 40px 30px; text-align: center;">
                            <h1 style="color: #ffffff; margin: 0; font-size: 36px;">🎅 Ho Ho Ho!</h1>
                            <p style="color: #ffffff; margin: 15px 0 0 0; font-size: 20px; font-weight: bold;">
                                ${childName}'s Christmas Video is Ready!
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Main Content -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <p style="margin: 0 0 20px 0; font-size: 18px; color: #333333;">
                                Hi ${parentName || 'there'},
                            </p>
                            
                            <p style="margin: 0 0 20px 0; font-size: 16px; line-height: 1.6; color: #333333;">
                                <strong>BIG UP!</strong> Your personalized DnB Santa video for ${childName} is ready to watch! 🎄
                            </p>
                            
                            <p style="margin: 0 0 30px 0; font-size: 16px; line-height: 1.6; color: #333333;">
                                Created with love from the North Pole (okay, from my van in Chipping Sodbury 🚐), 
                                this video is made SPECIALLY for ${childName}. PROPER personal, none of that generic stuff!
                            </p>
                            
                            <!-- CTA Button -->
                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto 30px auto;">
                                <tr>
                                    <td style="background-color: #dc2626; border-radius: 8px; text-align: center;">
                                        <a href="${videoUrl}" 
                                           style="display: inline-block; padding: 18px 40px; color: #ffffff; text-decoration: none; font-weight: bold; font-size: 18px;">
                                            🎬 Watch ${childName}'s Video
                                        </a>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- Instructions Box -->
                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f0fdf4; border-left: 4px solid #16a34a; border-radius: 8px; margin-bottom: 30px;">
                                <tr>
                                    <td style="padding: 20px;">
                                        <h3 style="margin: 0 0 10px 0; font-size: 18px; color: #16a34a;">💚 Tips for Maximum Magic:</h3>
                                        <ul style="margin: 10px 0 0 0; padding-left: 20px; color: #333333; line-height: 1.8;">
                                            <li>Watch it together for the BEST reaction!</li>
                                            <li>Your video link works for 7 days</li>
                                            <li>Feel free to download and keep forever</li>
                                            <li>Share with family (but keep it special for ${childName}!)</li>
                                        </ul>
                                    </td>
                                </tr>
                            </table>
                            
                            <p style="margin: 0 0 20px 0; font-size: 16px; line-height: 1.6; color: #333333;">
                                This service is COMPLETELY FREE and always will be - that's the "coffeeware" promise! 
                                If you can afford it and want to support the magic, donations are welcome but NEVER required. 
                                Otherwise, just share DnB Santa with someone else who might need it! Pay it forward! 💚
                            </p>
                            
                            <!-- Donation Links -->
                            <div style="text-align: center; margin: 30px 0;">
                                <p style="margin: 0 0 15px 0; font-size: 14px; color: #666666;">
                                    Support DnB Santa (only if you can):
                                </p>
                                <p style="margin: 0;">
                                    <a href="https://www.buymeacoffee.com/chrispteemagician" 
                                       style="color: #dc2626; text-decoration: none; margin: 0 10px;">
                                        ☕ Buy Me a Coffee
                                    </a>
                                    |
                                    <a href="https://www.ko-fi.com/zoom" 
                                       style="color: #dc2626; text-decoration: none; margin: 0 10px;">
                                        💚 Ko-fi
                                    </a>
                                </p>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f9fafb; padding: 30px; text-align: center; border-top: 1px solid #e5e7eb;">
                            <p style="margin: 0 0 10px 0; font-size: 16px; color: #333333; font-weight: bold;">
                                Ho ho ho! Merry Christmas! 🎄
                            </p>
                            <p style="margin: 0 0 15px 0; font-size: 14px; color: #666666;">
                                Made with love in a van by Chris P Tee<br>
                                Magic Circle Magician | UK Children's Entertainer 2018
                            </p>
                            <p style="margin: 0 0 10px 0; font-size: 12px; color: #999999;">
                                World domination through kindness 💚
                            </p>
                            <p style="margin: 0; font-size: 12px;">
                                <a href="https://dnbsanta.netlify.app" style="color: #dc2626; text-decoration: none;">
                                    dnbsanta.netlify.app
                                </a>
                                |
                                <a href="mailto:chris@chrisptee.co.uk" style="color: #dc2626; text-decoration: none;">
                                    chris@chrisptee.co.uk
                                </a>
                            </p>
                        </td>
                    </tr>
                    
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
    `;
  }

  /**
   * Send test email
   */
  async sendTestEmail(testEmail) {
    return this.sendVideoReadyEmail({
      parentEmail: testEmail,
      parentName: 'Test Parent',
      childName: 'Emma',
      videoUrl: 'https://example.com/test-video',
      requestId: 'test-123'
    });
  }
}

// Test function
export async function testEmailService() {
  const emailService = new EmailService(process.env.RESEND_API_KEY);
  
  console.log('📧 Testing email service...\n');
  console.log('⚠️ Note: Set TEST_EMAIL environment variable to send test email');
  
  if (process.env.TEST_EMAIL) {
    await emailService.sendTestEmail(process.env.TEST_EMAIL);
    console.log(`✅ Test email sent to ${process.env.TEST_EMAIL}`);
  } else {
    console.log('✅ Email service initialized successfully!');
  }
}
