import { createClient } from '@supabase/supabase-js';
import { ScriptGenerator } from './script-generator.js';
import { VoiceGenerator, LANGUAGE_CODES } from './voice-generator.js';
import { VideoGenerator } from './video-generator.js';
import { StorageManager } from './storage-manager.js';
import { EmailService } from './email-service.js';
import dotenv from 'dotenv';

dotenv.config();

/**
 * DnB Santa Automation Pipeline
 * Orchestrates the complete video generation workflow
 */

export class DnBSantaPipeline {
  constructor() {
    // Initialize all services
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_KEY
    );

    this.scriptGenerator = new ScriptGenerator(process.env.ANTHROPIC_API_KEY);
    
    this.voiceGenerator = new VoiceGenerator(
      process.env.ELEVENLABS_API_KEY,
      process.env.ELEVENLABS_VOICE_ID
    );

    this.videoGenerator = new VideoGenerator(
      process.env.VISIONSTORY_API_KEY,
      process.env.VISIONSTORY_AVATAR_ID
    );

    this.storageManager = new StorageManager(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_KEY,
      process.env.SUPABASE_STORAGE_BUCKET || 'dnb-santa-videos'
    );

    this.emailService = new EmailService(
      process.env.RESEND_API_KEY,
      process.env.FROM_EMAIL,
      process.env.FROM_NAME
    );
  }

  /**
   * Process a bonus friend greeting video
   * @param {string} childName - Name of child sending the greeting
   * @param {string} recipientName - Name of friend receiving the greeting
   * @param {string} parentEmail - Email to send the video to
   * @returns {Promise<Object>} - Processing result
   */
  async processBonusVideo(childName, recipientName, parentEmail) {
    console.log(`\n🎁 ===== PROCESSING BONUS VIDEO: ${childName} → ${recipientName} =====\n`);

    try {
      // Step 1: Generate bonus script
      console.log(`\n📝 Step 1/5: Generating bonus script...`);
      const script = await this.scriptGenerator.generateBonusScript(childName, recipientName);
      console.log(`Script: "${script}"`);

      // Step 2: Generate audio
      console.log(`\n🎤 Step 2/5: Generating voice with ElevenLabs...`);
      const audioBuffer = await this.voiceGenerator.generateAudio(script, 'en');

      // Step 3: Generate video
      console.log(`\n🎬 Step 3/5: Creating video with VisionStory...`);
      const videoOptions = {
        resolution: process.env.VIDEO_RESOLUTION || '720',
        model: process.env.VIDEO_MODEL || 'V-Talk',
        aspectRatio: '16:9'
      };
      const videoBuffer = await this.videoGenerator.generateCompleteVideo(audioBuffer, videoOptions);

      // Step 4: Upload to Supabase Storage
      console.log(`\n📤 Step 4/5: Uploading to Supabase Storage...`);
      const bonusId = `bonus_${Date.now()}`;
      const uploadResult = await this.storageManager.uploadVideo(videoBuffer, bonusId);

      // Step 5: Send email to parent
      console.log(`\n📧 Step 5/5: Sending email...`);
      await this.emailService.sendBonusVideoEmail({
        parentEmail,
        childName,
        recipientName,
        videoUrl: uploadResult.publicUrl
      });

      console.log(`\n✅ ===== BONUS VIDEO COMPLETED SUCCESSFULLY =====\n`);

      return {
        success: true,
        videoUrl: uploadResult.publicUrl,
        childName,
        recipientName
      };

    } catch (error) {
      console.error(`\n❌ Error processing bonus video:`, error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Process a single video request from start to finish
   * @param {string} requestId - Request ID from Supabase
   * @returns {Promise<Object>} - Processing result
   */
  async processRequest(requestId) {
    console.log(`\n🎅 ===== PROCESSING REQUEST ${requestId} =====\n`);

    try {
      // Step 1: Fetch request from database
      const request = await this.fetchRequest(requestId);
      if (!request) {
        throw new Error(`Request ${requestId} not found`);
      }

      console.log(`📋 Request for: ${request.child_name} (${request.language || 'English'})`);

      // Step 2: Update status to 'processing'
      await this.updateRequestStatus(requestId, 'processing');

      // Step 3: Generate script
      console.log(`\n📝 Step 1/5: Generating personalized script...`);
      const script = await this.scriptGenerator.generateValidatedScript(request);
      await this.updateRequestField(requestId, 'script', script);
      console.log(`Script preview: "${script.substring(0, 100)}..."`);

      // Step 4: Generate audio
      console.log(`\n🎤 Step 2/5: Generating voice with ElevenLabs...`);
      const languageCode = LANGUAGE_CODES[request.language] || 'en';
      const audioBuffer = await this.voiceGenerator.generateAudio(script, languageCode);

      // Step 5: Generate video
      console.log(`\n🎬 Step 3/5: Creating video with VisionStory...`);
      const videoOptions = {
        resolution: process.env.VIDEO_RESOLUTION || '720',
        model: process.env.VIDEO_MODEL || 'V-Talk',
        aspectRatio: '16:9'
      };
      const videoBuffer = await this.videoGenerator.generateCompleteVideo(audioBuffer, videoOptions);

      // Step 6: Upload to Supabase Storage
      console.log(`\n📤 Step 4/5: Uploading to Supabase Storage...`);
      const uploadResult = await this.storageManager.uploadVideo(videoBuffer, requestId);
      await this.updateRequestField(requestId, 'video_url', uploadResult.publicUrl);
      await this.updateRequestField(requestId, 'video_path', uploadResult.path);

      // Step 7: Send email to parent
      console.log(`\n📧 Step 5/5: Sending email to parent...`);
      await this.emailService.sendVideoReadyEmail({
        parentEmail: request.parent_email,
        parentName: request.parent_name,
        childName: request.child_name,
        videoUrl: uploadResult.publicUrl,
        requestId: requestId
      });

      // Step 8: Mark as completed
      await this.updateRequestStatus(requestId, 'completed', new Date().toISOString());

      console.log(`\n✅ ===== REQUEST ${requestId} COMPLETED SUCCESSFULLY =====\n`);

      return {
        success: true,
        requestId,
        videoUrl: uploadResult.publicUrl,
        childName: request.child_name
      };

    } catch (error) {
      console.error(`\n❌ Error processing request ${requestId}:`, error);
      
      // Update status to 'failed' with error message
      await this.updateRequestStatus(requestId, 'failed');
      await this.updateRequestField(requestId, 'error_message', error.message);

      return {
        success: false,
        requestId,
        error: error.message
      };
    }
  }

  /**
   * Fetch request from Supabase
   */
  async fetchRequest(requestId) {
    const { data, error } = await this.supabase
      .from('video_requests')
      .select('*')
      .eq('id', requestId)
      .single();

    if (error) throw error;
    return data;
  }

  /**
   * Update request status
   */
  async updateRequestStatus(requestId, status, completedAt = null) {
    const updates = {
      status,
      updated_at: new Date().toISOString()
    };

    if (completedAt) {
      updates.completed_at = completedAt;
    }

    const { error } = await this.supabase
      .from('video_requests')
      .update(updates)
      .eq('id', requestId);

    if (error) throw error;
    console.log(`✅ Status updated: ${status}`);
  }

  /**
   * Update a specific field in the request
   */
  async updateRequestField(requestId, field, value) {
    const { error } = await this.supabase
      .from('video_requests')
      .update({ 
        [field]: value,
        updated_at: new Date().toISOString()
      })
      .eq('id', requestId);

    if (error) throw error;
  }

  /**
   * Get all pending requests
   */
  async getPendingRequests(limit = 10) {
    const { data, error } = await this.supabase
      .from('video_requests')
      .select('*')
      .eq('status', 'pending')
      .order('created_at', { ascending: true })
      .limit(limit);

    if (error) throw error;
    return data || [];
  }

  /**
   * Process all pending requests (batch mode)
   */
  async processAllPending(maxConcurrent = 1) {
    console.log(`\n🎅 ===== BATCH PROCESSING MODE =====\n`);

    const pending = await this.getPendingRequests(maxConcurrent);
    
    if (pending.length === 0) {
      console.log('✅ No pending requests found!');
      return [];
    }

    console.log(`📋 Found ${pending.length} pending request(s)\n`);

    const results = [];

    // Process one at a time to avoid rate limits
    for (const request of pending) {
      const result = await this.processRequest(request.id);
      results.push(result);

      // Small delay between requests
      await new Promise(resolve => setTimeout(resolve, 2000));
    }

    console.log(`\n🎅 ===== BATCH PROCESSING COMPLETE =====`);
    console.log(`✅ Successful: ${results.filter(r => r.success).length}`);
    console.log(`❌ Failed: ${results.filter(r => !r.success).length}\n`);

    return results;
  }

  /**
   * Get processing statistics
   */
  async getStats() {
    const { data, error } = await this.supabase
      .from('video_requests')
      .select('status');

    if (error) throw error;

    const stats = {
      total: data.length,
      pending: data.filter(r => r.status === 'pending').length,
      processing: data.filter(r => r.status === 'processing').length,
      completed: data.filter(r => r.status === 'completed').length,
      failed: data.filter(r => r.status === 'failed').length
    };

    return stats;
  }
}

/**
 * Main function for testing/running the pipeline
 */
export async function runPipeline() {
  const pipeline = new DnBSantaPipeline();

  // Show stats
  const stats = await pipeline.getStats();
  console.log('\n📊 Current Stats:');
  console.log(`   Total Requests: ${stats.total}`);
  console.log(`   Pending: ${stats.pending}`);
  console.log(`   Processing: ${stats.processing}`);
  console.log(`   Completed: ${stats.completed}`);
  console.log(`   Failed: ${stats.failed}\n`);

  // Process all pending
  if (stats.pending > 0) {
    await pipeline.processAllPending();
  } else {
    console.log('✅ No pending requests to process!\n');
  }
}

// If running directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runPipeline().catch(console.error);
}
