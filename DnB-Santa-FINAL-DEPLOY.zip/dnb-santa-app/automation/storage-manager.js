import { createClient } from '@supabase/supabase-js';

/**
 * Supabase Storage Manager
 * Handles secure video file uploads and URL generation
 */

export class StorageManager {
  constructor(supabaseUrl, supabaseKey, bucketName = 'dnb-santa-videos') {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.bucketName = bucketName;
  }

  /**
   * Initialize storage bucket (run once on setup)
   */
  async initializeBucket() {
    try {
      // Check if bucket exists
      const { data: buckets } = await this.supabase.storage.listBuckets();
      const bucketExists = buckets?.some(b => b.name === this.bucketName);

      if (!bucketExists) {
        // Create bucket
        const { data, error } = await this.supabase.storage.createBucket(this.bucketName, {
          public: false, // Private bucket for security
          fileSizeLimit: 52428800, // 50MB limit
          allowedMimeTypes: ['video/mp4', 'video/quicktime', 'video/x-msvideo']
        });

        if (error) throw error;
        console.log(`✅ Storage bucket '${this.bucketName}' created`);
      } else {
        console.log(`✅ Storage bucket '${this.bucketName}' already exists`);
      }

      return true;
    } catch (error) {
      console.error('Error initializing bucket:', error);
      throw error;
    }
  }

  /**
   * Upload video to Supabase Storage
   * @param {Buffer} videoBuffer - Video file as buffer
   * @param {string} requestId - Request ID for file naming
   * @returns {Promise<Object>} - Upload result with path and URL
   */
  async uploadVideo(videoBuffer, requestId) {
    try {
      const filename = `${requestId}-${Date.now()}.mp4`;
      const filepath = `videos/${filename}`;

      console.log(`📤 Uploading video to Supabase Storage: ${filepath}`);

      const { data, error } = await this.supabase.storage
        .from(this.bucketName)
        .upload(filepath, videoBuffer, {
          contentType: 'video/mp4',
          cacheControl: '3600',
          upsert: false
        });

      if (error) throw error;

      console.log(`✅ Video uploaded successfully: ${filepath}`);

      // Generate signed URL (valid for 7 days)
      const signedUrl = await this.getSignedUrl(filepath, 604800); // 7 days in seconds

      return {
        path: filepath,
        fullPath: data.path,
        publicUrl: signedUrl
      };

    } catch (error) {
      console.error('Error uploading video:', error);
      throw new Error(`Video upload failed: ${error.message}`);
    }
  }

  /**
   * Get a signed URL for private video access
   * @param {string} filepath - Path to file in storage
   * @param {number} expiresIn - Seconds until expiry (default 7 days)
   * @returns {Promise<string>} - Signed URL
   */
  async getSignedUrl(filepath, expiresIn = 604800) {
    try {
      const { data, error } = await this.supabase.storage
        .from(this.bucketName)
        .createSignedUrl(filepath, expiresIn);

      if (error) throw error;

      return data.signedUrl;

    } catch (error) {
      console.error('Error generating signed URL:', error);
      throw error;
    }
  }

  /**
   * Delete video from storage
   * @param {string} filepath 
   */
  async deleteVideo(filepath) {
    try {
      const { error } = await this.supabase.storage
        .from(this.bucketName)
        .remove([filepath]);

      if (error) throw error;

      console.log(`🗑️ Video deleted: ${filepath}`);
      return true;

    } catch (error) {
      console.error('Error deleting video:', error);
      return false;
    }
  }

  /**
   * Get storage usage stats
   */
  async getStorageStats() {
    try {
      const { data: files } = await this.supabase.storage
        .from(this.bucketName)
        .list('videos');

      if (!files) return { totalFiles: 0, totalSize: 0 };

      const totalSize = files.reduce((sum, file) => sum + (file.metadata?.size || 0), 0);
      const totalSizeMB = (totalSize / 1024 / 1024).toFixed(2);

      return {
        totalFiles: files.length,
        totalSize: totalSize,
        totalSizeMB: totalSizeMB
      };

    } catch (error) {
      console.error('Error getting storage stats:', error);
      return null;
    }
  }

  /**
   * List all videos in storage
   */
  async listVideos(limit = 100) {
    try {
      const { data: files, error } = await this.supabase.storage
        .from(this.bucketName)
        .list('videos', {
          limit: limit,
          sortBy: { column: 'created_at', order: 'desc' }
        });

      if (error) throw error;

      return files;

    } catch (error) {
      console.error('Error listing videos:', error);
      return [];
    }
  }
}

// Test function
export async function testStorageManager() {
  const storage = new StorageManager(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_KEY
  );

  console.log('📦 Testing Supabase Storage integration...\n');

  // Initialize bucket
  await storage.initializeBucket();

  // Get stats
  const stats = await storage.getStorageStats();
  if (stats) {
    console.log(`📊 Storage Stats:`);
    console.log(`   Files: ${stats.totalFiles}`);
    console.log(`   Total Size: ${stats.totalSizeMB} MB`);
  }

  console.log('\n✅ Storage manager test complete!');
}
