import fetch from 'node-fetch';
import fs from 'fs/promises';
import path from 'path';

/**
 * ElevenLabs Voice Generator
 * Converts scripts into audio using Chris P Tee's voice clone
 */

export class VoiceGenerator {
  constructor(apiKey, voiceId) {
    this.apiKey = apiKey;
    this.voiceId = voiceId;
    this.baseUrl = 'https://api.elevenlabs.io/v1';
  }

  /**
   * Add emotion tags to script for V3 model
   * @param {string} script - Raw script
   * @returns {string} - Script with emotion tags
   */
  addEmotionTags(script) {
    // Add opening excitement
    script = script.replace(/^(Ho ho ho!)/i, '[excited] $1');
    script = script.replace(/(BIG UP!?)/gi, '[excited] $1');
    
    // Add warmth to greetings
    script = script.replace(/(Is that \w+\?)/i, '[warm, enthusiastic] $1');
    script = script.replace(/(\w+!)\s*Oh/i, '[warm] $1 [gasps] Oh');
    
    // Add pride/warmth to achievements
    script = script.replace(/(I'm SO proud|SO impressed|PROUD of you)/gi, '[proud, warm] $1');
    script = script.replace(/(been watching|I saw|I noticed|I heard)/gi, '[warm] $1');
    
    // Add excitement to DnB lingo
    script = script.replace(/(FIRE!?|PROPER|HEAVYWEIGHT|MASSIVE)/gi, '[excited] $1');
    script = script.replace(/(CLOCKED IT)/gi, '[playful] $1');
    
    // Add warmth to encouragement
    script = script.replace(/(Keep being|Keep practicing|Keep trying)/gi, '[warm, encouraging] $1');
    script = script.replace(/(You're on the NICE list)/gi, '[happy, warm] $1');
    
    // Add joy to closing
    script = script.replace(/(Merry Christmas)/gi, '[warm, joyful] $1');
    script = script.replace(/(RESPECT!?)\s*$/gi, '[happy] $1');
    
    // Add laughing to "ho ho ho" if not already tagged
    script = script.replace(/(?<!\])\s*(Ho ho ho)/gi, ' [laughing] $1');
    
    return script;
  }

  /**
   * Generate audio from script
   * @param {string} script - The script to convert to speech
   * @param {string} language - Target language (e.g., 'en', 'es', 'fr')
   * @returns {Promise<Buffer>} - Audio file as buffer
   */
  async generateAudio(script, language = 'en') {
    const url = `${this.baseUrl}/text-to-speech/${this.voiceId}`;

    // Add emotion tags for V3 model
    const taggedScript = this.addEmotionTags(script);
    console.log(`🎭 Added emotion tags to script`);

    const requestBody = {
      text: taggedScript,
      model_id: 'eleven_turbo_v3', // V3 for best emotion and accent control!
      voice_settings: {
        stability: 0.5,
        similarity_boost: 0.75,
        style: 0.6,
        use_speaker_boost: true
      },
      language_code: language
    };

    try {
      console.log(`🎤 Generating audio with ElevenLabs...`);
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': this.apiKey
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`ElevenLabs API error: ${response.status} - ${error}`);
      }

      const audioBuffer = await response.buffer();
      console.log(`✅ Audio generated successfully (${(audioBuffer.length / 1024).toFixed(2)} KB)`);
      
      return audioBuffer;
      
    } catch (error) {
      console.error('Error generating audio:', error);
      throw new Error(`Voice generation failed: ${error.message}`);
    }
  }

  /**
   * Save audio buffer to file
   * @param {Buffer} audioBuffer 
   * @param {string} filename 
   */
  async saveAudioFile(audioBuffer, filename) {
    const outputPath = path.join(process.cwd(), 'temp', filename);
    await fs.mkdir(path.dirname(outputPath), { recursive: true });
    await fs.writeFile(outputPath, audioBuffer);
    console.log(`💾 Audio saved to: ${outputPath}`);
    return outputPath;
  }

  /**
   * Get accent/style guidance for native pronunciation
   * @param {string} language - Language code
   * @returns {string} - Style guidance text
   */
  getAccentGuidance(language) {
    const accentGuides = {
      'es': 'Native Spanish speaker, warm and enthusiastic, authentic accent from Spain or Latin America',
      'fr': 'Native French speaker, warm grandfatherly voice, authentic Parisian accent',
      'de': 'Native German speaker, warm and friendly, authentic accent',
      'it': 'Native Italian speaker, warm and expressive, authentic accent',
      'pt': 'Native Portuguese speaker, warm and friendly, authentic accent from Portugal or Brazil',
      'nl': 'Native Dutch speaker, warm and clear, authentic accent',
      'pl': 'Native Polish speaker, warm and friendly, authentic accent',
      'ru': 'Native Russian speaker, warm grandfatherly voice, authentic accent',
      'ar': 'Native Arabic speaker, warm and respectful, authentic accent',
      'hi': 'Native Hindi speaker, warm and friendly, authentic accent',
      'zh': 'Native Mandarin speaker, warm and clear, authentic accent',
      'ja': 'Native Japanese speaker, warm and respectful, authentic accent',
      'ko': 'Native Korean speaker, warm and friendly, authentic accent',
      'tr': 'Native Turkish speaker, warm and enthusiastic, authentic accent',
      'sv': 'Native Swedish speaker, warm and clear, authentic accent',
      'da': 'Native Danish speaker, warm and friendly, authentic accent',
      'no': 'Native Norwegian speaker, warm and clear, authentic accent',
      'fi': 'Native Finnish speaker, warm and friendly, authentic accent',
      'el': 'Native Greek speaker, warm and expressive, authentic accent',
      'cs': 'Native Czech speaker, warm and friendly, authentic accent',
      'ro': 'Native Romanian speaker, warm and clear, authentic accent',
      'hu': 'Native Hungarian speaker, warm and friendly, authentic accent',
      'uk': 'Native Ukrainian speaker, warm and friendly, authentic accent',
      'vi': 'Native Vietnamese speaker, warm and clear, authentic accent',
      'th': 'Native Thai speaker, warm and respectful, authentic accent',
      'id': 'Native Indonesian speaker, warm and friendly, authentic accent',
      'ms': 'Native Malay speaker, warm and clear, authentic accent',
      'tl': 'Native Tagalog speaker, warm and friendly, authentic accent',
      'he': 'Native Hebrew speaker, warm and clear, authentic accent',
      'bn': 'Native Bengali speaker, warm and friendly, authentic accent',
      'ta': 'Native Tamil speaker, warm and respectful, authentic accent',
      'ur': 'Native Urdu speaker, warm and friendly, authentic accent',
      'fa': 'Native Persian speaker, warm and respectful, authentic accent',
      'sw': 'Native Swahili speaker, warm and friendly, authentic accent',
      'en': 'Warm British accent with slight urban energy, friendly and enthusiastic'
    };

    return accentGuides[language] || 'Warm, friendly, and natural speaking voice';
  }

  /**
   * Get available voices
   */
  async getVoices() {
    const url = `${this.baseUrl}/voices`;
    
    try {
      const response = await fetch(url, {
        headers: {
          'xi-api-key': this.apiKey
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch voices: ${response.status}`);
      }

      const data = await response.json();
      return data.voices;
      
    } catch (error) {
      console.error('Error fetching voices:', error);
      throw error;
    }
  }

  /**
   * Get voice details and verify it exists
   */
  async verifyVoice() {
    try {
      const voices = await this.getVoices();
      const voice = voices.find(v => v.voice_id === this.voiceId);
      
      if (!voice) {
        console.warn(`⚠️ Voice ID ${this.voiceId} not found`);
        return false;
      }
      
      console.log(`✅ Voice verified: ${voice.name}`);
      return true;
      
    } catch (error) {
      console.error('Error verifying voice:', error);
      return false;
    }
  }
}

/**
 * Language code mapper for ElevenLabs
 */
export const LANGUAGE_CODES = {
  'English': 'en',
  'Spanish': 'es',
  'French': 'fr',
  'German': 'de',
  'Italian': 'it',
  'Portuguese': 'pt',
  'Dutch': 'nl',
  'Polish': 'pl',
  'Russian': 'ru',
  'Arabic': 'ar',
  'Hindi': 'hi',
  'Mandarin': 'zh',
  'Japanese': 'ja',
  'Korean': 'ko',
  'Turkish': 'tr',
  'Swedish': 'sv',
  'Danish': 'da',
  'Norwegian': 'no',
  'Finnish': 'fi',
  'Greek': 'el',
  'Czech': 'cs',
  'Romanian': 'ro',
  'Hungarian': 'hu',
  'Ukrainian': 'uk',
  'Vietnamese': 'vi',
  'Thai': 'th',
  'Indonesian': 'id',
  'Malay': 'ms',
  'Tagalog': 'tl',
  'Hebrew': 'he',
  'Bengali': 'bn',
  'Tamil': 'ta',
  'Urdu': 'ur',
  'Persian': 'fa',
  'Swahili': 'sw'
};

// Test function
export async function testVoiceGenerator() {
  const generator = new VoiceGenerator(
    process.env.ELEVENLABS_API_KEY,
    process.env.ELEVENLABS_VOICE_ID
  );
  
  console.log('🎤 Testing ElevenLabs integration...\n');
  
  // Verify voice exists
  await generator.verifyVoice();
  
  // Generate test audio
  const testScript = "Ho ho ho! BIG UP! This is a test of the DnB Santa voice generation system. PROPER vibes incoming!";
  const audio = await generator.generateAudio(testScript, 'en');
  
  // Save to temp file
  const filename = `test-audio-${Date.now()}.mp3`;
  await generator.saveAudioFile(audio, filename);
  
  console.log('\n✅ Voice generation test complete!');
}
