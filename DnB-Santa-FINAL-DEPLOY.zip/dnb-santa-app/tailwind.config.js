/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'dnb-red': '#DC2626',
        'dnb-green': '#16A34A',
        'dnb-gold': '#F59E0B',
      }
    },
  },
  plugins: [],
}
