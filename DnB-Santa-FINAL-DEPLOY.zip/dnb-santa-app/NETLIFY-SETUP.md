# 🚀 Netlify Deployment with Automation

## Step 1: Deploy to Netlify

### Option A: Drag & Drop
1. Run `npm install` and `npm run build` locally
2. Go to https://app.netlify.com/drop
3. Drag the `dist` folder
4. Done!

### Option B: GitHub (Recommended)
1. Push code to GitHub
2. Connect repo to Netlify
3. Build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Functions directory: `netlify/functions`

---

## Step 2: Add Environment Variables

Go to: **Site settings → Environment variables**

Add these variables:

```
VITE_SUPABASE_URL=https://lauswgjnlghltkbwszgx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxhdXN3Z2pubGdobHRrYndzemd4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI3MTIyNTQsImV4cCI6MjA3ODI4ODI1NH0.4KJIK54eaCipImrVJHZyLMjdPuv50xtsaqaewnCUUnM

SUPABASE_SERVICE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxhdXN3Z2pubGdobHRrYndzemd4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI3MTIyNTQsImV4cCI6MjA3ODI4ODI1NH0.4KJIK54eaCipImrVJHZyLMjdPuv50xtsaqaewnCUUnM

ANTHROPIC_API_KEY=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

ELEVENLABS_API_KEY=sk_c96a57550108bf55680e5ec91da6fea225854a890df502ba
ELEVENLABS_VOICE_ID=CpgDUW6FZ9xBvrG7Zcqz

VISIONSTORY_API_KEY=sk-vs-YISqPNagymfgo2HcmCusxVctDkHVAsJHPlQ7I8z6oTVmQmGF
VISIONSTORY_AVATAR_ID=97f31d98cfbf5ea1fe0474f6b84ec7cd_7102_10_16

RESEND_API_KEY=re_eMrCBeWt_Dyz6KW7ZG7wZnh5cKbW9g2F8
FROM_EMAIL=chris@chrisptee.co.uk
FROM_NAME=DnB Santa
```

---

## Step 3: Update Supabase Schema

Run this SQL in Supabase SQL Editor:

```sql
-- Add new columns for automation
ALTER TABLE video_requests
ADD COLUMN IF NOT EXISTS script TEXT,
ADD COLUMN IF NOT EXISTS video_path TEXT,
ADD COLUMN IF NOT EXISTS error_message TEXT,
ADD COLUMN IF NOT EXISTS completed_at TIMESTAMP,
ADD COLUMN IF NOT EXISTS progress TEXT;

-- Add language column if not exists
ALTER TABLE video_requests
ADD COLUMN IF NOT EXISTS language TEXT DEFAULT 'English';
```

---

## Step 4: Test the Automation

1. Go to your admin dashboard: `yourdomain.netlify.app/admin`
2. Find a pending request
3. Click "🤖 Generate Video"
4. Wait 3-5 minutes
5. Video will be generated and parent will receive email!

---

## 🎯 How It Works

**When you click "Generate Video":**
1. ✅ Claude generates personalized script
2. ✅ ElevenLabs creates voice in selected language
3. ✅ VisionStory produces video with Santa avatar
4. ✅ Video uploaded to Supabase Storage
5. ✅ Parent receives beautiful email with video link
6. ✅ Status updated to "completed"

**All automatic! No manual work needed!** 🎅✨

---

## 💰 Costs

**Per Video:**
- Claude API: ~£0.01
- ElevenLabs: (your credits)
- VisionStory: 4 credits (~£0.33)
- **Total: ~£0.34/video**

**Netlify:**
- FREE for up to 125,000 function calls/month
- Background functions have no timeout!

---

## 🔧 Troubleshooting

### "Function not found"
- Check Netlify build logs
- Verify `netlify.toml` is in root directory
- Redeploy site

### "Video generation failed"
- Check Netlify function logs
- Verify all environment variables are set
- Check API key validity

### "Email not sent"
- Verify Resend domain (chris@chrisptee.co.uk)
- Check Resend dashboard for delivery status

---

## 🎉 You're Done!

Your DnB Santa site now has full automation! 

Click "Generate Video" and watch the magic happen! 🎅💚✨
