-- DnB Santa Database Schema for Supabase
-- Run this in your Supabase SQL Editor

-- Create video_requests table
CREATE TABLE IF NOT EXISTS video_requests (
  id BIGSERIAL PRIMARY KEY,
  child_name TEXT NOT NULL,
  child_age INTEGER,
  parent_name TEXT,
  parent_email TEXT NOT NULL,
  interests TEXT,
  wish_list TEXT,
  encouragement TEXT,
  video_url TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index on status for faster queries
CREATE INDEX IF NOT EXISTS idx_video_requests_status ON video_requests(status);

-- Create index on created_at for sorting
CREATE INDEX IF NOT EXISTS idx_video_requests_created_at ON video_requests(created_at DESC);

-- Enable Row Level Security
ALTER TABLE video_requests ENABLE ROW LEVEL SECURITY;

-- Policy: Anyone can insert (public form submission)
CREATE POLICY "Anyone can submit video requests"
  ON video_requests
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Policy: Anyone can read their own requests (by email)
CREATE POLICY "Users can read their own requests"
  ON video_requests
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Policy: Service role can do everything (admin operations)
CREATE POLICY "Service role has full access"
  ON video_requests
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_video_requests_updated_at
  BEFORE UPDATE ON video_requests
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Grant permissions
GRANT ALL ON video_requests TO service_role;
GRANT SELECT, INSERT ON video_requests TO anon;
GRANT SELECT, INSERT ON video_requests TO authenticated;
