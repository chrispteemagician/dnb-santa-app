# DnB Santa Deployment Guide 🎅

## Quick Start (5 Steps)

### 1. Setup Supabase Database

1. Go to https://supabase.com/dashboard/project/lauswgjnlghltkbwszgx
2. Click **SQL Editor** in the left sidebar
3. Open `supabase-schema.sql` from this package
4. Copy all the SQL and paste it into the editor
5. Click **Run** to create the database table

### 2. Deploy to Netlify

1. Go to https://app.netlify.com/
2. Drag and drop the **entire `dnb-santa-app` folder** onto Netlify
3. Wait for the build to complete (2-3 minutes)
4. Your site will be live at a random URL like `https://random-name-123.netlify.app`

### 3. Configure Environment Variables in Netlify

1. In Netlify, go to **Site settings** → **Environment variables**
2. Add these variables:

```
VITE_SUPABASE_URL = https://lauswgjnlghltkbwszgx.supabase.co
VITE_SUPABASE_ANON_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxhd...
VITE_SUPABASE_SERVICE_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxhd...
```

3. Click **Save**
4. Go to **Deploys** → **Trigger deploy** → **Deploy site** to rebuild with the new env vars

### 4. Migrate Existing Data (Optional)

If you have existing video requests in TiDB:

1. Open a terminal in the `dnb-santa-app` folder
2. Run: `npm install`
3. Run: `node migrate-data.js`
4. Check the output - you should see "✅ Success: 10" (or however many requests you have)

### 5. Test the Site

1. Visit your Netlify URL
2. Submit a test video request
3. Check the **Admin Dashboard** at `https://your-site.netlify.app/admin`
4. Verify the request appears in the dashboard

---

## Admin Dashboard Access

The admin dashboard is at `/admin` on your deployed site.

**Mobile-first design** - works perfectly on your Pixel 8 Pro! 📱

Features:
- View all video requests
- Filter by status (pending/processing/completed/failed)
- Update video URLs
- Mark videos as completed
- Send confirmation emails

---

## Manual Video Creation Workflow

1. User submits form → request saved as "pending"
2. You receive the request in the admin dashboard
3. Create video manually in Vision Story
4. Copy the video URL
5. Update the request in admin dashboard:
   - Paste video URL
   - Change status to "completed"
   - Check "Email sent" if you've sent it manually

---

## Rate Limiting

- **3 videos per email per season** (hard-coded in `src/pages/Home.jsx`)
- Simple in-memory tracking (resets when app restarts)
- To change the limit, edit the `RATE_LIMIT` constant in `Home.jsx`

---

## Content Filtering

Basic keyword filtering is built into `Home.jsx`:
- Blocks spam/inappropriate words
- Checks child name, interests, wish list, and encouragement fields
- Shows error message to user if blocked

To customize, edit the `BLOCKED_KEYWORDS` array in `Home.jsx`.

---

## Donation Links

Ko-fi and Buy Me a Coffee buttons are on the confirmation page.

Current links:
- Ko-fi: https://ko-fi.com/chrisptee
- Buy Me a Coffee: https://www.buymeacoffee.com/chrisptee

To change, edit `src/pages/Confirmation.jsx`.

---

## Custom Domain (Optional)

1. In Netlify, go to **Domain settings**
2. Click **Add custom domain**
3. Follow the instructions to point your DNS to Netlify
4. Netlify will automatically provision an SSL certificate

---

## Troubleshooting

### "Could not find table" error when migrating data
→ Make sure you ran the SQL schema in Supabase first (Step 1)

### Form submission doesn't work
→ Check that environment variables are set in Netlify and you've redeployed

### Admin dashboard is empty
→ Check the browser console for errors. Make sure the service key is set correctly.

### Videos aren't being created
→ This is expected! The workflow is manual. You create videos in Vision Story and update the records manually.

---

## Support

If you need help, reach out to Manus support or check the README.md file for more details.

🎅 **Merry Christmas from DnB Santa!** 🎄
